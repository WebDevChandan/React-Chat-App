// let shadowHost = document.querySelector('.shadow-host'),
//   shadowChild = shadowHost.createShadowRoot();