package com.cg.bankapp.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class BankDatabase {
	static Statement stmnt;
	static boolean tableCreated =false;

	public BankDatabase() throws SQLException, ClassNotFoundException {
		Connection conn = DBConnection.getConnection();
		
		// Create Statement
		stmnt = conn.createStatement();

		// TABLE CREATION
		createTable();

		// TABLE INSERTION
		insertTable();

		//CLOSE Connection
		conn.close();
	}

	public static void createTable() throws SQLException {
		// Account Table
		String accTable = "create table if not exists Account(accId int not null primary key, accBal double not null, accType varchar(10))";
		stmnt.executeUpdate(accTable);

		// Customer Table
		String cusTable = "create table if not exists Customer (cusId int not null primary key, cusName varchar(10) not null, account_no int not null, Foreign key (account_no) References account(accId))";
		stmnt.executeUpdate(cusTable);

		// Transaction Table
		String transTable = "create table if not exists Transaction(tranId int not null primary key AUTO_INCREMENT, tranType varchar(10) not null, amountTransfer double not null, account_no int not null, Foreign key (account_no) References account(accId))";
		stmnt.executeUpdate(transTable);
		String transTableQuery = "alter table Transaction Auto_Increment = 1001";
		stmnt.executeUpdate(transTableQuery);
		
		tableCreated = true;
	}

	public static void insertTable() throws SQLException {
		if(!tableCreated) {
			// Account Insertion
			String accInsert = "insert into Account(accId, accBal, accType)values(123450, 1000.0, 'Salary'),"
					+ "(123456, 200.0, 'Salary')," + "(123457, 300.0, 'Salary')," + "(123458, 400.0, 'Salary'),"
					+ "(123459, 500.0, 'Salary')," + "(123451, 60.0, 'Salary')," + "(123452, 700.0, 'Salary'),"
					+ "(123453, 400.0, 'Salary')," + "(123454, 250.0, 'Salary')," + "(123455, 550.0, 'Salary')";
			stmnt.executeUpdate(accInsert);
			
			// Customer Insertion
			String cusInsert = "insert into Customer(cusId, cusName, account_no)values(101, 'Chandan', 123450),"
					+ "(201, 'Aditya', 123456)," + "(301, 'Mayur', 123457)," + "(401, 'Vishal', 123458),"
					+ "(501, 'Amar', 123459)," + "(601, 'Misha', 123451)," + "(701, 'Malhar', 123452),"
					+ "(801, 'Amar',123453)," + "(901, 'Aniket', 123454)," + "(001, 'Gaurav', 123455)";
			stmnt.executeUpdate(cusInsert);
		}
	}

}
