package com.cg.bankapp.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankDAO {
	public double updateBalance(Account account, double balance, double amount, String transType) throws SQLException,ClassNotFoundException;
	public boolean save(Account account);
	public Account getAccountById(int accountId) throws AccountNotFoundException, ClassNotFoundException,SQLException;
}

