package com.cg.bankapp.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.beans.Transaction;
import com.cg.bankapp.dao.BankDAOImpl;
import com.cg.bankapp.exceptions.*;
import com.cg.bankapp.util.Color;

public class BankServiceImpl implements BankService {
	int sourceTransactionCount = 0;

	@Override
	public double showBalance(Account accGotById) {
		double balance = 0.0;
		balance = accGotById.getAccountBalance();

		return balance;
	}

	@Override
	public double deposit(Account accGotById, double amount)throws NegativeAmountException, SQLException, ClassNotFoundException {
		BankDAOImpl updateAccBal = new BankDAOImpl();
		
		double balance = accGotById.getAccountBalance();
		balance += amount;
		
		if (amount < 0)
			throw new NegativeAmountException("Amount Can't be Negative");
		else {

			// Setting the updated Account Balance to the Account Object
			accGotById.setAccountBalance(updateAccBal.updateBalance(accGotById, balance, amount, "\"Credit\"" ));

		}

		// Getting The updated account Balance from the Account Object
		return balance;
	}

	@Override
	public double withdraw(Account accGotById, double amount)
			throws InsufficientBalanceException, NegativeAmountException, ClassNotFoundException, SQLException {
		BankDAOImpl updateAccBal = new BankDAOImpl();

		double balance = accGotById.getAccountBalance();
		if (amount > balance)
			throw new InsufficientBalanceException("Insufficient Balance");
		else if (amount < 0)
			throw new NegativeAmountException("Amount Can't be Negative");
		else {
			balance -= amount;

			

			// Setting the updated Account Balance to the Account Object
			accGotById.setAccountBalance(updateAccBal.updateBalance(accGotById, balance, amount, "\"Debited\"" ));
			System.out.println(Color.TXTGREEN + amount + " withdrawl Successfully!" + Color.RESET);

		}

		return balance;
	}

	@Override
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)
			throws InsufficientBalanceException, NegativeAmountException, SameAccountException,
			AccountNotFoundException, ClassNotFoundException, SQLException {
		BankDAOImpl updateAccBal = new BankDAOImpl();
		
		if (sourceAccount==targetAccount)
			throw new SameAccountException("Can't trsfer Fund to the Same Account");

		double sourceAccountBal = sourceAccount.getAccountBalance();
		double targetAccountBal = targetAccount.getAccountBalance();

		if (amount > sourceAccountBal)
			throw new InsufficientBalanceException("Insufficient Balance");
		else if (amount < 0)
			throw new NegativeAmountException("Amount Can't be negative");
		else {
			sourceAccountBal -= amount;
			targetAccountBal += amount;
	
			sourceAccount.setAccountBalance(updateAccBal.updateBalance(sourceAccount, sourceAccountBal, amount, "\"Debited\""));
			targetAccount.setAccountBalance(updateAccBal.updateBalance(targetAccount, targetAccountBal, amount, "\"Credited\""));
		}

		return targetAccountBal;
	}

	@Override
	public List<Transaction> getAllTransactionDetails(Account accGotById) throws NoTransactionFoundException {

		if (accGotById.getTransaction().isEmpty())
			throw new NoTransactionFoundException("No Transaction Found");

		return accGotById.getTransaction();
	}

}
