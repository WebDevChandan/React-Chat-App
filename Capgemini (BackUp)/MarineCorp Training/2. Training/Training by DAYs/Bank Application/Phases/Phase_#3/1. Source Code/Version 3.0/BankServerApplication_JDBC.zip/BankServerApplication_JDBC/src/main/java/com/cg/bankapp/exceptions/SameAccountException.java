package com.cg.bankapp.exceptions;

public class SameAccountException extends Exception{
	public SameAccountException(String msg) {
		super(msg);
	}
}
