package com.bankapp.main;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.dao.*;
import com.cg.bankapp.exceptions.NoTransactionFoundException;
import com.cg.bankapp.exceptions.SameAccountException;
import com.cg.bankapp.service.*;
import com.cg.bankapp.util.*;

public class BankAppMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Color clr = new Color();
		// Initializing instance of color class to access all defined colors.

		System.out.println(clr.BGWHITE + clr.TXTPURPLE + "BANK SERVER APPLICATION:- " + clr.RESET);

		Scanner keyboard = new Scanner(System.in);

		// Getting Account DataBase from BankDatabase
//		BankDatabase bDb = new BankDatabase();
//		HashMap<Integer, Account> getAccDb = bDb.getAccountDb();

		// Taking Bank Services
		BankServiceImpl bnkSrvImpl = new BankServiceImpl();

		// Finding Account as per Given Account Number
		BankDAOImpl findAcc = new BankDAOImpl();

		/**
		 * Since, Each Account belongs to Each customer, we're going to get the whole
		 * application's access only to one customer who enter their account number at
		 * First.
		 */
		Account accGotById = new Account();
		int accNum =0;
		do {
			System.out.print("Enter Account Number: ");

			try {
				accNum = keyboard.nextInt();
				accGotById = findAcc.getAccountById(accNum);

				System.out.println(
						clr.TXTYELLOW + "Welcome! " + accGotById.getCustomer().getcustomerName() + " 😊" + clr.RESET);

			} catch (Exception err) {
				System.err.println(err);
				System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
				System.out.println("");
			}

			// CustomerId will be 0 (by default) till account number doesn't fetch correctly
		} while (accGotById.getCustomer().customerId == 0);

		int choice;
		do {
			choice = showMenu(keyboard);
			switch (choice) {
			case 1:
				System.out.println(clr.TXTYELLOW + accGotById.getCustomer().getcustomerName() + " Your Balance is: "
						+ bnkSrvImpl.showBalance(accGotById) + clr.RESET);
				break;

			case 2:
				double currAccBal = accGotById.getAccountBalance();
				
				do {
					try {
						System.out.print("Enter Amount to Deposit: ");
						double amount = keyboard.nextDouble();
						double updatedAccBal= bnkSrvImpl.deposit(accGotById, amount);

						if (currAccBal != updatedAccBal) {
							System.out.println(clr.TXTGREEN + amount + " Deposited Successfully" + clr.RESET);
							System.out.println(clr.TXTYELLOW + "New Balance: " + updatedAccBal + clr.RESET);
						}

					} catch (Exception err) {
						System.err.println(err);
						System.out.println(clr.TXTYELLOW + "Negative Amount not Allowed!" + clr.RESET);
						System.out.println("");
					}

				} while (currAccBal == accGotById.getAccountBalance());
				break;
//
			case 3:

				System.out.println(
						clr.TXTYELLOW + "Available Balance: " + bnkSrvImpl.showBalance(accGotById) + clr.RESET);

				do {
					currAccBal = accGotById.getAccountBalance();
					try {
						System.out.print("Enter Amount to Withdraw: ");
						double amount = keyboard.nextDouble();

						double newBal = bnkSrvImpl.withdraw(accGotById, amount);
						if (currAccBal != newBal)
							System.out.println(clr.TXTYELLOW + "New Balance: " + newBal + clr.RESET);
						else
							break;

					} catch (Exception err) {
						System.err.println(err);
						System.out.println(clr.TXTYELLOW + "Please Enter the Correct Amount" + clr.RESET);
						System.out.println("");
					}
					
				} while (accGotById.getAccountBalance() == currAccBal);
				break;
//
			case 4:

				Account targetAccount = new Account();
				double currTargetBal = targetAccount.getAccountBalance();
				
				do {

					if (targetAccount.getCustomer().customerId == 0)
						System.out.print("Enter 2nd Account Number (To): ");
					try {
						int targetAccNum = keyboard.nextInt();
						if (targetAccNum == accNum)
							// Can't send Amount to the same account
							throw new SameAccountException("Can't Transfer Fund to the Same Account");

						targetAccount = findAcc.getAccountById(targetAccNum);

						System.out.println("");
						System.out.println(clr.TXTBLUE + "Note: Your're Transfering Money to --> "
								+ targetAccount.getCustomer().getcustomerName() + clr.RESET);
						double newTargetBal = 0;
						double amount=0;
						do {
						
							try{
								
								System.out.print("Enter Amount to Transfer: ");
								amount = keyboard.nextDouble();
								
								newTargetBal = bnkSrvImpl.fundTransfer(accGotById, targetAccount, amount);
							}catch (Exception err) {
								System.err.println(err);
								System.out.println(clr.TXTYELLOW + "Please Enter the Correct Amount!" + clr.RESET);
								System.out.println("");
							}

						}while(currTargetBal == newTargetBal );
						
						if (currTargetBal != newTargetBal)
							System.out.println(clr.TXTGREEN + amount + " Transfered Successfully!!" + clr.RESET);
						
					} catch (Exception err) {
						System.err.println(err);
						System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
						System.out.println("");
					}

					// CustomerId will be 0 (by default) till account number doesn't fetch correctly
				} while (targetAccount.getCustomer().customerId == 0 );

				break;
//
			case 5:

				try {
					List<Transaction> transaction = bnkSrvImpl.getAllTransactionDetails(accGotById);

					boolean transacitonFound = false;
					int transactionCount = 0;
					
					for (int i = transaction.size() - 1; i >= 0 && transactionCount<10; i--) {
						if (transaction.get(i) != null) {
							System.out.println(clr.TXTYELLOW + transaction.get(i) + clr.RESET);
							transacitonFound = true;
							transactionCount++;
						}
					}

					if (!transacitonFound) 						
						throw new NoTransactionFoundException("No Transaction Found");
				} catch (Exception err) {
					System.err.println(err);
					System.out.println(clr.TXTYELLOW + "No, Transaction Found!" + clr.RESET);
				}

				break;

			case 6:
				System.out.println(clr.TXTBLUE + "Thanks, for using my application!" + clr.RESET);
				break;
				
			default:
				break;
			}

		} while (choice != 6);
	}

	/*
	 * Since, This is a menu Driven Application, we letting customer to use this
	 * application by using menu Choice.
	 * 
	 */
	public static int showMenu(Scanner keyboard) {
		int choice=1;
		// This menu will appear again if customer enter the wrong choice.
		do {
			if(choice < 1 || choice > 6)
				System.out.println("Invalid Menu Choice");
				
			System.out.println("");
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Transfer Fund");
			System.out.println("5. Get Transaction Details (Last 10 Transactions)");
			System.out.println("6. Exit");
			System.out.println("");
			System.out.print("Enter Choice: ");

			choice = keyboard.nextInt();
		} while (choice < 1 || choice > 6);
		return choice;
	}
}
