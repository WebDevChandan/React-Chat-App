package com.cg.bankapp.exceptions;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException(String str){
		super(str);
	}
}
