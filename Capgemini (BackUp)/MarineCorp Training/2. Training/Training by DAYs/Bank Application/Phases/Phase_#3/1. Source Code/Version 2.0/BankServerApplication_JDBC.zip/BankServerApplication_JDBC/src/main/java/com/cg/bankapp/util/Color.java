package com.cg.bankapp.util;

public class Color {
	public final String RESET;
	public final String BGWHITE;
	public final String TXTBLACK;
	public final String TXTGREEN;
	public final String TXTBLUE;
	public final String TXTPURPLE;
	public final String TXTYELLOW;
	
	public Color() {
		BGWHITE ="\u001B[47m";
		 RESET  = "\u001B[0m";
		 TXTBLACK = "\u001B[30m";
		 TXTGREEN = "\u001B[32m";
		 TXTBLUE = "\u001B[34m";
		 TXTPURPLE = "\u001B[35m";
		 TXTYELLOW = "\u001B[33m";
	}
}

