package com.cg.bankapp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;
import com.cg.bankapp.util.DBConnection;

public class BankDAOImpl implements BankDAO {
	Connection conn;
	Statement stmnt;

	public BankDAOImpl() throws ClassNotFoundException, SQLException {
		conn = DBConnection.getConnection();
		stmnt = conn.createStatement();
	}

	@Override
	// Get the required Account as per User's Account Number
	public Account getAccountById(int accountId) throws AccountNotFoundException, ClassNotFoundException, SQLException {
		Map<Integer, Account> account = new HashMap<Integer, Account>();

		// SQL Query
		String accCusQuery = "Select * from account a, customer c where a.accId = c.account_no And c.account_no="
				+ accountId;

		// ResultSet Interface: For fetching Record
		ResultSet rsAccCus = stmnt.executeQuery(accCusQuery);

		boolean accountFound = false;

		if (rsAccCus.next()) {
			int accId = rsAccCus.getInt(1);
			double accBal = rsAccCus.getDouble(2);
			int cusId = rsAccCus.getInt(4);
			String cusName = rsAccCus.getString(5);

			account.put(accId, new Account(accId, new Customer(cusId, cusName), accBal));

			accountFound = save(account.get(accountId));
		}

		if (!accountFound) {
			throw new AccountNotFoundException("Account Not Found");
		}

		
		//If account has done any Previous Transaction, then it will get load 
		//all the previous transactions
		String accTranQuery = "Select * from account a, transaction t where a.accId = t.account_no And t.account_no="
				+ account.get(accountId).getAccountNumber();

		ResultSet rsAccTran = stmnt.executeQuery(accTranQuery);
		while(rsAccTran.next()) {			
			int tranId = rsAccTran.getInt(4);
			String tranType = rsAccTran.getString(5);
			double amountTransfer = rsAccTran.getDouble(6);

			account.get(accountId).getTransaction().add(new Transaction(tranId, amountTransfer, tranType));
		}

		// Returning Account as per given account Number
		return account.get(accountId);

	}

	@Override
	public boolean save(Account account) {
		boolean accountStatus = false;
		if (account != null)
			accountStatus = true;

		return accountStatus;
	}


	@Override
	public double updateBalance(Account accGotById, double balance, double amount, String transType)
			throws SQLException, ClassNotFoundException {

		// TRANSACTION DETAIL ADDING
		String tranInsert = "insert into Transaction(tranType, amountTransfer, account_no)values("
				+ transType + ", " + amount + "," + accGotById.getAccountNumber() + ")";
		stmnt.executeUpdate(tranInsert);

		
		String accTranQuery = "Select * from account a, transaction t where a.accId = t.account_no And t.account_no="
				+ accGotById.getAccountNumber();

		ResultSet rsAccTran = stmnt.executeQuery(accTranQuery);
		

		//Clearing the List
		accGotById.getTransaction().clear();
		
		while(rsAccTran.next()) {	
			int newTranId = rsAccTran.getInt(4);
			String tranType = rsAccTran.getString(5);
			double amountTransfer = rsAccTran.getDouble(6);
			
			//If transId match with the newTransId (i.e. tranId of new current transaction) out of all 
			//previous transaction present in the database, then add to transaction arrayLIst.
				accGotById.getTransaction().add(new Transaction(newTranId, amountTransfer, tranType));
		}
			
			
			

		// Updating Balance to the Account
		stmnt.executeUpdate("Update account set accBal=" + balance + " Where accId=" + accGotById.getAccountNumber());

		// ResultSet Interface: For fetching Account Record
		ResultSet rsForUpdateAccBal = stmnt
				.executeQuery("Select * from account Where accId= " + accGotById.getAccountNumber());

		
		// Getting the Updated Balance from the Database
		rsForUpdateAccBal.next();
		double updatedBal = rsForUpdateAccBal.getDouble(2);

		return updatedBal;

	}

}