package com.cg.bankapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		String mysqlJDBCDriver = "com.mysql.cj.jdbc.Driver";
		String jdbcurl = "jdbc:mysql://localhost:3306/BankApp";
		String user = "root";
		String pwd = "root";

		// Load Driver
		Class.forName(mysqlJDBCDriver);

		// Connect JDBC
		Connection  conn = DriverManager.getConnection(jdbcurl, user, pwd);

		return conn;

	}
}
