package com.cg.bankapp.beans;

public class Customer {
	public int customerId;
	private String customerName;
	
	public Customer(){
		
	}

	public Customer(int custId, String custName){
		this.customerId=custId;
		this.customerName=custName;
	}

	public Integer getcustomerId() {
		Integer custId = customerId;
		return custId;
	}
	public String  getcustomerName() {
		String custName = customerName;
		return custName;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	

}
