package com.cg.bankapp.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class BankDatabase {
	static Statement stmnt;
	static boolean tableCreated =false;

	public BankDatabase() throws SQLException, ClassNotFoundException {
		Connection conn = DBConnection.getConnection();
		
		//Create Statement
		stmnt = conn.createStatement();

		// TABLE CREATION
		createTable();

		// TABLE INSERTION
		insertTable();

		//CLOSE Connection
		conn.close();
	}

	public static void createTable() throws SQLException {
		// Account Table
		stmnt.executeUpdate(DBConstant.accTable);

		// Customer Table
		stmnt.executeUpdate(DBConstant.cusTable);

		// Transaction Table
		stmnt.executeUpdate(DBConstant.transTable);
		
		stmnt.executeUpdate(DBConstant.transTableId);
		
		tableCreated = true;
	}

	public static void insertTable() throws SQLException {
		if(!tableCreated) {
			// Account Insertion
			stmnt.executeUpdate(DBConstant.accInsert);
			
			// Customer Insertion
			stmnt.executeUpdate(DBConstant.cusInsert);
		}
		System.out.println("Table with Value inserted");
	}

}
