package com.cg.bankapp.exceptions;

public class NoTransactionFoundException extends Exception{
	public NoTransactionFoundException(String msg) {
		super(msg);
	}
}
