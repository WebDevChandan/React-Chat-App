package com.cg.bankapp.bankservice;

import java.util.ArrayList;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.beans.Transaction;
import com.cg.bankapp.util.*;
import com.cg.bankapp.exceptions.*;

public class BankServiceImpl implements BankService{
	static int sourceTransactionCount =0;		
	Color clr = new Color();
	
	@Override
	public double showBalance(Account accGotById) {
		double balance = 0.0;
		balance = accGotById.getAccountBalance();
		 return balance;		
	}

	@Override
	public double deposit(Account accGotById, double amount) throws NegativeAmountException{
		double balance = accGotById.getAccountBalance();
		
		if(amount<0)
			throw new NegativeAmountException("Amount Can't be Negative");
		else{
			balance += amount;
			accGotById.setAccountBalance(balance);
			
			//Storing Deposit as Transaction
			int depoTransId = (int)Math.floor(Math.random()*1000000);
			
			accGotById.getTransaction().add(new Transaction(depoTransId , amount, "Credited"));
			sourceTransactionCount++;
			
		}
		return balance;
	}

	@Override
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException, NegativeAmountException{

		double balance = accGotById.getAccountBalance();
			if(amount>balance)
				throw new InsufficientBalanceException("Insufficient Balance");
			else if(amount<0)
				throw new NegativeAmountException("Amount Can't be Negative");
			else{				
				balance -= amount;
				
				accGotById.setAccountBalance(balance);
				System.out.println(clr.TXTGREEN +amount + " withdrawl Successfully!" + clr.RESET);
				
				//Storing withdraw as Transaction
				int withDrawTransId = (int)Math.floor(Math.random()*1000000);
				accGotById.getTransaction().add(new Transaction(withDrawTransId , amount, "Debited"));
				sourceTransactionCount++;
			}
		
		return balance;
	}

	@Override
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount) throws InsufficientBalanceException, NegativeAmountException, SameAccountException,AccountNotFoundException {
		if(sourceAccount == targetAccount)
			throw new SameAccountException("Can't trsfer Fund to the Same Account");
		
		double sourceAccountBal = sourceAccount.getAccountBalance();
		double targetAccountBal = targetAccount.getAccountBalance();
		
			if(amount>sourceAccountBal)
				throw new InsufficientBalanceException("Insufficient Balance");
			else if(amount<0)
				throw new NegativeAmountException("Amount Can't be negative");
			else{				
				sourceAccountBal -=amount;
				targetAccountBal +=amount;
				
				//Generating a random number as transactionId  for Source Account
				int sourceTransId = (int)Math.floor(Math.random()*1000000);
				
				//Storing SourceAccount's Transaction Details
				sourceAccount.getTransaction().add(new Transaction(sourceTransId, amount, "Debited"));
				sourceTransactionCount++;
				
				
				
				sourceAccount.setAccountBalance(sourceAccountBal);
				targetAccount.setAccountBalance(targetAccountBal);
			}
			
		return targetAccountBal;
	}

	@Override
	public ArrayList<Transaction> getAllTransactionDetails(Account accGotById) throws NoTransactionFoundException {
		
		if(accGotById.getTransaction().isEmpty())
			throw new NoTransactionFoundException("No Transaction Found");
		
		return accGotById.getTransaction();
	}
	
}
