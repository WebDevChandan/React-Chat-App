package com.cg.BankServerApplication;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import com.cg.bankapp.bankdao.BankDAOImpl;
import com.cg.bankapp.bankservice.BankServiceImpl;
import com.cg.bankapp.beans.Account;
import com.cg.bankapp.exceptions.AccountNotFoundException;
import com.cg.bankapp.exceptions.InsufficientBalanceException;
import com.cg.bankapp.exceptions.NegativeAmountException;
import com.cg.bankapp.exceptions.NoTransactionFoundException;
import com.cg.bankapp.exceptions.SameAccountException;
import com.cg.bankapp.util.BankDatabase;

public class BankServiceImplTest {
	// Getting Account DataBase from BankDatabase
	BankDatabase bDb = new BankDatabase();
	HashMap<Integer, Account> getAccDb = bDb.getAccountDb();;

	BankDAOImpl daoImpl = new BankDAOImpl();
	BankServiceImpl serviceImpl = new BankServiceImpl();
	Account sourceAcc = getAccDb.get(123450);
	Account targetAcc = getAccDb.get(123451);

	@Test
	@DisplayName("Account Not found, if account Number is wrong")
	public void test_AccountNotFound_shouldthrowException() throws AccountNotFoundException {
		assertThrows(AccountNotFoundException.class, () -> daoImpl.getAccountById(getAccDb, 123), "No Account Found");
	}

//	@Test
//	@DisplayName("Intially, No Transaciton will Found till no transaction takes place")
//	public void test_NoTransactionFound_shouldthrowException() throws NoTransactionFoundException {
//		assertThrows(NoTransactionFoundException.class, () -> assertTrue( "If transaction size is 0", serviceImpl.getAllTransactionDetails(sourceAcc).size() == 0),
//				"No Transaction Found");
//
//		// If no transaction takes place its Size would be 0.
//		assertTrue("If no transaction takes place", serviceImpl.getAllTransactionDetails(sourceAcc).size() == 0);
//	}

	@Test
	@DisplayName("Checking Balance of an Account")
	public void checkBalance() {
		assertEquals(serviceImpl.showBalance(sourceAcc), 1000, 0.0);

	}

	@Test
	@DisplayName("Depositing Amount to the account")
	public void depositAmount() throws NegativeAmountException {
		double amount = 1000;

		// Updated Account Balance After Deposit
		double accountBalance = sourceAcc.getAccountBalance() + amount;

		assertTrue("If deposited, accBal should Increase", serviceImpl.showBalance(sourceAcc) < accountBalance);
		assertEquals(serviceImpl.deposit(sourceAcc, amount), accountBalance, 0.0);
	}

	@Test
	@DisplayName("Negative Amount trying to Deposit")
	public void testDepost_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.deposit(sourceAcc, -100),
				"Negative Amount Deposit");
	}

	@Test
	@DisplayName("Withdrawling Amount from the account")
	public void withdrawAmount() throws InsufficientBalanceException, NegativeAmountException {
		double amount = 1000.00;

		// Updated Account Balance After Withdrawn
		double accountBalance = sourceAcc.getAccountBalance() - amount;

		assertTrue("If Withdrawl, accBal should Decrease", serviceImpl.showBalance(sourceAcc) > accountBalance);
		assertEquals(serviceImpl.withdraw(sourceAcc, amount), accountBalance, 0.0);
	}

	@Test
	@DisplayName("Insufficient Balance Exception")
	public void testWithdraw_InsufficientBal_shouldThrowException() throws InsufficientBalanceException {
		assertThrows(InsufficientBalanceException.class, () -> serviceImpl.withdraw(sourceAcc, 10000),
				"Insuffiencet Balance");
	}

	@Test
	@DisplayName("Negative Amount Exception")
	public void testWithdraw_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.withdraw(sourceAcc, -10),
				"Amount Can't be Negative");
	}

	@Test
	@DisplayName("Tranferring fund from Source Account to Target Account")
	public void fundTransfer() throws InsufficientBalanceException, NegativeAmountException, SameAccountException,
			AccountNotFoundException {
		double amount = 500;

		// Updated Account Balance After Fund withdrawn from Source Account
		double accountBalance1 = sourceAcc.getAccountBalance() - amount;

		// Updated Account Balance After transfer Fund to 2nd Account
		double accountBalance2 = targetAcc.getAccountBalance() + amount;

		assertTrue("After withdrawl, Source account's Bal should Decrease",
				serviceImpl.showBalance(sourceAcc) > accountBalance1);
		assertTrue("If transfer fund, Target account's Bal should Increase",
				serviceImpl.showBalance(targetAcc) < accountBalance2);

		assertEquals(serviceImpl.fundTransfer(sourceAcc, targetAcc, amount), accountBalance2, 0.0);
	}

	@Test
	@DisplayName("Trying Insufficient Amount to Tranfer")
	public void testFundTransfer_InsufficientAmount_shouldThrowException() throws InsufficientBalanceException {
		assertThrows(InsufficientBalanceException.class, () -> serviceImpl.fundTransfer(sourceAcc, targetAcc, 100000),
				"Insufficient Amount");
	}

	@Test
	@DisplayName("Trying Negative Amount to Tranfer")
	public void testFundTransfer_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.fundTransfer(sourceAcc, targetAcc, -1),
				"Amount Can't be Negative");
	}

	@Test
	@DisplayName("Can't Transfer fund to the same account")
	public void testFundTransfer_SameAccount_shouldThrowException() throws SameAccountException {
		assertThrows(SameAccountException.class, () -> serviceImpl.fundTransfer(sourceAcc, sourceAcc, 100),
				"Can't Tranfer fund to the same Account");
	}

	@Test
	@DisplayName("Account Not Found, If target Acount Number is wrong")
	public void testFundTransfer_AccountNotFound_shouldThrowException() throws NullPointerException {
		assertThrows(NullPointerException.class, () -> serviceImpl.fundTransfer(sourceAcc, getAccDb.get(111), 100),
				"Account Not Found");
	}

	@Test
	@DisplayName("Transaction Saved")
	public void transactionDetailsSaved() throws NoTransactionFoundException {
		// If any transaction takes place, this would not null i.e. true
		assertNotNull("If deposit, withdraw or fund Transfer takes place from source account ",
				serviceImpl.getAllTransactionDetails(sourceAcc));

		// If no transaction takes place its Size would be 0. Since here transaction is
		// taking place, hence this would not be 0 anymore.
		assertFalse("If no transaction takes place", serviceImpl.getAllTransactionDetails(sourceAcc).size() == 0);
	}

	@AfterAll
	void tearDownAfterClass() throws Exception {
		getAccDb.clear();
	}

}
