package com.cg.bankapp.bankdao;

import java.util.HashMap;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankDAO {
	public boolean save(Account account);
	public Account getAccountById(HashMap<Integer, Account> account, int accountId) throws AccountNotFoundException;
}

