package com.cg.bankapp.bankservice;

import java.util.ArrayList;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankService {
	public double showBalance(Account accGotById);
	public double deposit(Account accGotById, double amount) throws NegativeAmountException;
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException, NegativeAmountException;
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)throws InsufficientBalanceException, NegativeAmountException, SameAccountException, AccountNotFoundException; 
	ArrayList<Transaction> getAllTransactionDetails(Account AccGotById) throws NoTransactionFoundException;
}
