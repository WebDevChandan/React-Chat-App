package com.cg.bankapp.bankdao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public class BankDAOImpl implements BankDAO{
	
	@Override
	//Get the required Account as per User's Account Number
	public Account getAccountById(HashMap<Integer, Account> accountDb, int accountId) throws AccountNotFoundException{
		boolean accountFound = false;
		int key=0;
		
		for(Map.Entry<Integer, Account> entry: accountDb.entrySet()) {
			if(entry.getKey() == accountId) {
				key= entry.getKey();
				accountFound = true;
				break;
			}
		}
		if(!accountFound) {
			throw new AccountNotFoundException("Account Not Found");
		}
			
		
		return accountDb.get(key); 
	}
	

	@Override
	public boolean save(Account account) {
		return false;
	}
}