package com.cg.exceptionhandler.handler;

public class SameAccountException {

}
