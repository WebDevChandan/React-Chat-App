package com.cg.exceptionhandler;

import java.io.IOException;
import java.util.Arrays;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import org.w3c.dom.NodeList;

public class DOMParser {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		Document document = builder.parse("Exceptions.xml");
		NodeList moduleList = document.getElementsByTagName("module");
		
		
		for (int i = 0; i < moduleList.getLength(); i++) {
            Node moduleNode = moduleList.item(i);
            if (moduleNode.getNodeType() == Node.ELEMENT_NODE) {
                Element moduleElement = (Element) moduleNode;
                String moduleName = moduleElement.getAttribute("name");
                System.out.println("Module name: " + moduleName);
                NodeList exceptionList = moduleElement.getElementsByTagName("exception");
                for (int j = 0; j < exceptionList.getLength(); j++) {
                    Node exceptionNode = exceptionList.item(j);
                    if (exceptionNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element exceptionElement = (Element) exceptionNode;
                        String exceptionName = exceptionElement.getAttribute("name");
                        System.out.println("  Exception name: " + exceptionName);
                        NodeList actionsList = exceptionElement.getElementsByTagName("actions");
                        for (int k = 0; k < actionsList.getLength(); k++) {
                            Node actionsNode = actionsList.item(k);
                            if (actionsNode.getNodeType() == Node.ELEMENT_NODE) {
                                Element actionsElement = (Element) actionsNode;
                                // Extract and print the SMS message details    
                                NodeList smsList = actionsElement.getElementsByTagName("sms");
                                
                                    Node smsNode = smsList.item(0);
                                    if (smsNode.getNodeType() == Node.ELEMENT_NODE) {
                                        Element smsElement = (Element) smsNode;
                                        String toNumber = smsElement.getAttribute("to");
                                        String smsBody = smsElement.getAttribute("sms_body");
                                        System.out.println("    SMS to: " + toNumber + ", message: " + smsBody);
                                    }
                                
                                // Extract and print the email message details                 
                                NodeList emailList = actionsElement.getElementsByTagName("email");
                                
                                    Node emailNode = emailList.item(0);
                                    if (emailNode.getNodeType() == Node.ELEMENT_NODE) {
                                        Element emailElement = (Element) emailNode;
                                        String toAddress = emailElement.getAttribute("to");
                                        String emailBody = emailElement.getAttribute("email_body");
                                        System.out.println("    Email to: " + toAddress + ", message: " + emailBody);
                                    }
                               
                                // Extract and print the log details       
                                NodeList logList = actionsElement.getElementsByTagName("log");
                                
                                    Node logNode = logList.item(0);
                                    if (logNode.getNodeType() == Node.ELEMENT_NODE) {
                                        Element logElement = (Element) logNode;
                                        String logName = logElement.getAttribute("name");
                                        String logFile = logElement.getAttribute("file");
                                        System.out.println("    Log name: " + logName + ", file: " + logFile);
                                    }
                                
                            }
                        }
                    }
                }
            }
        }
	}
}
