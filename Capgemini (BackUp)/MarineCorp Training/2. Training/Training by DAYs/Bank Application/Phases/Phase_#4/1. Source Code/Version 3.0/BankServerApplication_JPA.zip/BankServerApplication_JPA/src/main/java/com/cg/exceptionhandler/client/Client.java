package com.cg.exceptionhandler.client;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cg.exceptionhandler.handler.AccountNotFoundException;
import com.cg.exceptionhandler.handler.ExceptionHandler;

public class Client {
	final String File_Name = "Exceptions.xml";
	public static Map<String, Map<String, Map<String, Map<String, String>>>> config = new LinkedHashMap<String, Map<String, Map<String, Map<String, String>>>>();

	public void readXMLUsingDOM() {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder docBuilder = factory.newDocumentBuilder();
			Document doc = docBuilder.parse(new File(File_Name));
			doc.getDocumentElement().normalize();
			String rootName = doc.getDocumentElement().getNodeName();
			System.out.println("Root Element: " + rootName);

			NodeList moduleList = doc.getElementsByTagName("module");

			for (int i = 0; i < moduleList.getLength(); i++) {
				Node moduleNode = moduleList.item(i);
				if (moduleNode.getNodeType() == Node.ELEMENT_NODE) {
					Element moduleElement = (Element) moduleNode;
					String moduleName = moduleElement.getAttribute("name");
					System.out.println("Module name: " + moduleName);
					NodeList exceptionList = moduleElement.getElementsByTagName("exception");
					Map<String, Map<String, Map<String, String>>> exceptionMap = new LinkedHashMap<>();

					for (int j = 0; j < exceptionList.getLength(); j++) {
						Node exceptionNode = exceptionList.item(j);
						if (exceptionNode.getNodeType() == Node.ELEMENT_NODE) {
							Element exceptionElement = (Element) exceptionNode;
							String exceptionName = exceptionElement.getAttribute("name");
							System.out.println("  Exception name: " + exceptionName);

							NodeList actionsList = exceptionElement.getElementsByTagName("actions");
							Node actionNode = actionsList.item(0);
							Element actionsElement = (Element) actionNode;
							NodeList allActionNode = actionsElement.getChildNodes();
							Map<String, Map<String, String>> actionsMap = new LinkedHashMap<>();

							for (int k = 0; k < actionsList.getLength(); k++) {
								Node singleActionsNode = allActionNode.item(k);
								if (singleActionsNode.getNodeType() == Node.ELEMENT_NODE) {
									String nodeName = singleActionsNode.getNodeName();
									System.out.println(nodeName);
									Element singleElement = (Element) singleActionsNode;
									NamedNodeMap attributeList =singleElement.getAttributes();
									Map<String, String> attributeMap = new LinkedHashMap<>();
									for(int l=0; l<attributeList.getLength(); l++) {
										Node attribute = attributeList.item(l);
										String name = attribute.getNodeName();
										String value = attribute.getNodeValue();
										System.out.println(name+" -> " + value);
										attributeMap.put(name, value);
									}
								}
								exceptionMap.put(exceptionName, actionsMap);
							}
							config.put(moduleName, exceptionMap);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String[] args)throws AccountNotFoundException, ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Client obj = new Client();
		obj.readXMLUsingDOM();
		try {
			throw new AccountNotFoundException("");
		} catch (Exception e) {
			ExceptionHandler eh = new ExceptionHandler(e, "showBalance");
			eh.getHandler();
		}
	}
}
