package com.cg.exceptionhandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySAXParser extends DefaultHandler{
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("module")) {
            String moduleName = attributes.getValue("name");
            System.out.println("Module Name: " + moduleName);
        } else if (qName.equalsIgnoreCase("exception")) {
            String exceptionName = attributes.getValue("name");
            System.out.println("Exception Name: " + exceptionName);
        } else if (qName.equalsIgnoreCase("sms")) {
            String to = attributes.getValue("to");
            String smsBody = attributes.getValue("sms_body");
            System.out.println("SMS To: " + to);
            System.out.println("SMS Body: " + smsBody);
        } else if (qName.equalsIgnoreCase("email")) {
            String to = attributes.getValue("to");
            String emailBody = attributes.getValue("emailbody");
            System.out.println("Email To: " + to);
            System.out.println("Email Body: " + emailBody);
        } else if (qName.equalsIgnoreCase("log")) {
            String logName = attributes.getValue("name");
            String logFile = attributes.getValue("file");
            System.out.println("Log Name: " + logName);
            System.out.println("Log File: " + logFile);
        }
    }
    public static void main(String[] args) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            MySAXParser handler = new MySAXParser();
            saxParser.parse("Exceptions.xml", handler);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
