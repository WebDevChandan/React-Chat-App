package com.cg.bankapp.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	// Suppose to pass PERSISTENCE_UNIT_NAME unit Name
	private static final String PERSISTENCE_UNIT_NAME = "BankServer";
	private static EntityManagerFactory factory;

	private JPAUtil() {
	}
	
	public static EntityManagerFactory getEntityManagerFactory() {
		if (factory == null) {
			factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		}
		return factory;
	}

	public static void shutdown() {
		if (factory != null) {
			factory.close();
		}
	}
}
