package com.cg.bankapp.util;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.persistence.EntityManager;

import com.cg.bankapp.beans.Account;
import com.cg.bankapp.beans.Customer;


public class BankCrudOperation {

	private BankCrudOperation() {
	}
	
	public static void createAccount(EntityManager eM) {
		Hashtable<String, Double> map = new Hashtable<String, Double>();
		map.put("Chandan", 1000.0);
		map.put("Aditya", 200.0);
		map.put("Mayur", 300.0);
		map.put("Vishal", 400.0);
		map.put("Amar", 500.0);
		map.put("Misha", 60.0);
		map.put("Malhar", 700.0);
		map.put("Sakshi", 400.0);
		map.put("Ankiet", 250.0);
		map.put("Gaurav", 550.0);

		Enumeration<String> e = map.keys();
		
		 while(e.hasMoreElements()) {
			 String cusName = e.nextElement();
			 double cusBal = map.get(cusName);
			
			 Account account = new Account(new Customer(cusName), cusBal);
			 eM.getTransaction().begin();
			 eM.persist(account);
			 eM.getTransaction().commit();
		 }
	}
}
