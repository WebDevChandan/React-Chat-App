package com.cg.exceptionhandler.factory;

public abstract class Actions {
	public abstract void perform();
}
