package com.cg.exceptionhandler.factory;

import java.util.Map;

public class Log extends Actions{

	private String file;
	
	
	//constructor
	public Log(Map<String, String> mp) {
		this.file = mp.get("file");
	}
	
	@Override
	public void perform() {
		System.out.println(this);
	}

	@Override
	public String toString() {
		return "ShowLog [file=" + file + "]";
	}
	
	
	
}
