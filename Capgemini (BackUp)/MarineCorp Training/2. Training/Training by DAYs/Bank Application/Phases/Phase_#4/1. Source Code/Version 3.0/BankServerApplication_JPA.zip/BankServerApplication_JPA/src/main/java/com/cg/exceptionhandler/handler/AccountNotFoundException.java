package com.cg.exceptionhandler.handler;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException(String message) {
		super(message);
	}
}
