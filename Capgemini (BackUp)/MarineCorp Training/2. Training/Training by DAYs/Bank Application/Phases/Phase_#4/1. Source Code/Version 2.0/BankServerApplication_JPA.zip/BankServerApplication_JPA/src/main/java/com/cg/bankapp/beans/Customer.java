package com.cg.bankapp.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table
public class Customer {
	@Id
	@Column(name="cusID", nullable = false)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="cusId_generator")
	@SequenceGenerator(name="cusId_generator", initialValue = 101, allocationSize = 1, sequenceName = "cusId_seq")
	private int customerId;
	
	@Column(name="CustomerName")
	private String customerName;

	public Customer() {
		
	}
	public Customer(String custName){
		this.customerName=custName;
	}

	public Integer getcustomerId() {
		Integer custId = customerId;
		return custId;
	}
	public String  getcustomerName() {
		String custName = customerName;
		return custName;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	

}
