	package com.cg.exceptionhandler.handler;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;

import com.cg.exceptionhandler.client.Client;

public class ExceptionHandler {
	Object exceptionObject;
	String errorMessage;
	String moduleName;
	public static final Map<String, Map<String, Map<String, Map<String, String>>>> config = Client.config;
	public ExceptionHandler(Object exceptionObject, String moduleName) {
		this.exceptionObject=exceptionObject;
		this.moduleName = moduleName;
	}
	
	public void getHandler() throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		String exceptionClassName =exceptionObject.getClass().getSimpleName();
		Map<String, Map<String, String>> actions = config.get(moduleName).get(exceptionClassName);
		System.out.println("Actions are: ");
		Set<String> actionName = actions.keySet();
		for(String s: actionName) {
			String newString = s.substring(0,1).toUpperCase()+s.substring(1);
			Class<?> c = Class.forName("com.cg.exceptionhandler.factory."+newString);
			Constructor<?>constructor = c.getConstructor(Map.class);
			Object testObject = constructor.newInstance(actions.get(s));
			Method method = testObject.getClass().getMethod("perform");
			method.invoke(testObject);
		}
	}
}
