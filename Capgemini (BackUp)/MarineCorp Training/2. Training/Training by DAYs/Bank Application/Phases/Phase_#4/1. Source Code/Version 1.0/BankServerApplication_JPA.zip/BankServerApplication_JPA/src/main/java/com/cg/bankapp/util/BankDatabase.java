package com.cg.bankapp.util;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import com.cg.bankapp.beans.Account;
import com.cg.bankapp.beans.Customer;

public class BankDatabase {
	private static EntityManager eM;

	static {
		eM = JPAUtil.getEntityManagerFactory().createEntityManager();
	}
	
	public static void setupDB() {
			BankCrudOperation.createAccount(eM);
	}
	

	public static EntityManager getEntityManager() {
		return eM;
	}

//	public static void main(String[] args) {
//		new BankDatabase();
//	}
}
