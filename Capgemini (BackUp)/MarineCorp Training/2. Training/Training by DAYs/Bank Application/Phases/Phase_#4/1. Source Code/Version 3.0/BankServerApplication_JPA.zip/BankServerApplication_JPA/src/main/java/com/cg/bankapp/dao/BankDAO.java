package com.cg.bankapp.dao;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankDAO {
	/**
	Updates the balance and transaction history of the specified account in the database.
	@param account the account to update
	@param balance the new balance to set for the account
	@param amount the transaction amount
	@param transType the type of transaction (e.g. deposit, withdrawal)
	*/
	public void updateBalanceAndTransaction(Account account, double balance, double amount, String transType);
	
	/**
	Saves the specified account to the database.
	@param account the account to save
	@return true if the account was saved successfully, false otherwise
	*/
	public boolean save(Account account);
	
	/**
	Retrieves the account with the specified ID from the database.
	@param accountId the ID of the account to retrieve
	@return the account with the specified ID
	@throws AccountNotFoundException if the account with the specified ID cannot be found
	*/
	public Account getAccountById(int accountId) throws AccountNotFoundException;
}

