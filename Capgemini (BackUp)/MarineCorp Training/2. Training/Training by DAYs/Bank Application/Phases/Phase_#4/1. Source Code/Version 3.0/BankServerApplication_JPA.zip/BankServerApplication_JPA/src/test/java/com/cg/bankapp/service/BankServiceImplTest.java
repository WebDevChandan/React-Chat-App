package com.cg.bankapp.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;

import com.cg.bankapp.beans.Account;
import com.cg.bankapp.beans.Customer;
import com.cg.bankapp.dao.BankDAOImpl;
import com.cg.bankapp.exceptions.AccountNotFoundException;
import com.cg.bankapp.exceptions.InsufficientBalanceException;
import com.cg.bankapp.exceptions.NegativeAmountException;
import com.cg.bankapp.exceptions.NoTransactionFoundException;
import com.cg.bankapp.exceptions.SameAccountException;
import com.cg.bankapp.util.BankDatabase;
import com.cg.bankapp.util.JPAUtil;
import com.cg.bankapp.beans.*;

public class BankServiceImplTest {

	BankServiceImpl serviceImpl = new BankServiceImpl();
	BankDAOImpl daoImpl;
	Account sourceAccount;
	Account targetAccount;
	EntityManager eM;
	
	@Before
	@DisplayName("Before all Execution Setup")
	public void setup() throws ClassNotFoundException, SQLException {
		daoImpl = new BankDAOImpl();

		eM = JPAUtil.getEntityManagerFactory().createEntityManager();
		
		sourceAccount = eM.find(Account.class, 123450);
		targetAccount = eM.find(Account.class, 123451);
		System.out.println(sourceAccount);
		System.out.println(targetAccount);
		
	}
	
	@Test
	@DisplayName("Account Not found, if account Number is wrong")
	public void test_AccountNotFound_shouldthrowException() throws AccountNotFoundException {
		//Passing Wrong Account Number
		assertThrows(AccountNotFoundException.class, () -> daoImpl.getAccountById(123), "No Account Found");
	}
//
	@Test
	@DisplayName("Checking Balance of an Account")
	public void checkBalance() {
		assertEquals(sourceAccount.getAccountBalance(), serviceImpl.showBalance(sourceAccount), 0.0);

	}
	
//	@Test
//	@DisplayName("No Transaction should Found, if no transaction takes place")
//	public void testTransaction_NoTransactionFound_shouldThrowException()throws NoTransactionFoundException {
//		// If no transaction takes place, No transaction should Display
//		assertThrows(NoTransactionFoundException.class, () -> serviceImpl.getAllTransactionDetails(sourceAccount),
//				"Transaction Not Found");
//	}
	
	@Test
	@DisplayName("Depositing Amount to the account")
	public void depositAmount() throws NegativeAmountException, ClassNotFoundException, SQLException {
		double amount = 1000;

		// Updated Account Balance After Deposit
		double accountBalance = sourceAccount.getAccountBalance() + amount;

		assertTrue("If deposited, accBal should Increase", serviceImpl.showBalance(sourceAccount) < accountBalance);
		assertEquals(serviceImpl.deposit(sourceAccount, amount), accountBalance, 0.0);
	}
//
	@Test
	@DisplayName("Negative Amount trying to Deposit")
	public void testDepost_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.deposit(sourceAccount, -100),
				"Negative Amount Deposit");
	}
//
	@Test
	@DisplayName("Withdrawling Amount from the account")
	public void withdrawAmount() throws InsufficientBalanceException, NegativeAmountException, ClassNotFoundException, SQLException {
		double amount = 1.00;

		// Updated Account Balance After Withdrawn
		double accountBalance = sourceAccount.getAccountBalance() - amount;

		assertTrue("If Withdrawl, accBal should Decrease", serviceImpl.showBalance(sourceAccount) > accountBalance);
		assertEquals(serviceImpl.withdraw(sourceAccount, amount), accountBalance, 0.0);
	}
//
	@Test
	@DisplayName("Insufficient Balance Exception")
	public void testWithdraw_InsufficientBal_shouldThrowException() throws InsufficientBalanceException {
		assertThrows(InsufficientBalanceException.class, () -> serviceImpl.withdraw(sourceAccount, 10000),
				"Insuffiencet Balance");
	}
//
	@Test
	@DisplayName("Negative Amount Exception")
	public void testWithdraw_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.withdraw(sourceAccount, -10),
				"Amount Can't be Negative");
	}
//
	@Test
	@DisplayName("Tranferring fund from Source Account to Target Account")
	public void fundTransfer() throws InsufficientBalanceException, NegativeAmountException, SameAccountException,
			AccountNotFoundException, ClassNotFoundException, SQLException {
		double amount = 5;

		// Updated Account Balance After Fund withdrawn from Source Account
		double accountBalance1 = sourceAccount.getAccountBalance() - amount;

		// Updated Account Balance After transfer Fund to 2nd Account
		double accountBalance2 = targetAccount.getAccountBalance() + amount;

		assertTrue("After withdrawl, Source account's Bal should Decrease",
				serviceImpl.showBalance(sourceAccount) > accountBalance1);
		assertTrue("If transfer fund, Target account's Bal should Increase",
				serviceImpl.showBalance(targetAccount) < accountBalance2);

		assertEquals(serviceImpl.fundTransfer(sourceAccount, targetAccount, amount), accountBalance2, 0.0);
	}
//
	@Test
	@DisplayName("Trying Insufficient Amount to Tranfer")
	public void testFundTransfer_InsufficientAmount_shouldThrowException() throws InsufficientBalanceException {
		assertThrows(InsufficientBalanceException.class, () -> serviceImpl.fundTransfer(sourceAccount, targetAccount, 100000),
				"Insufficient Amount");
	}
//
	@Test
	@DisplayName("Trying Negative Amount to Tranfer")
	public void testFundTransfer_NegativeAmount_shouldThrowException() throws NegativeAmountException {
		assertThrows(NegativeAmountException.class, () -> serviceImpl.fundTransfer(sourceAccount, targetAccount, -1),
				"Amount Can't be Negative");
	}
//
	@Test
	@DisplayName("Can't Transfer fund to the same account")
	public void testFundTransfer_SameAccount_shouldThrowException() throws SameAccountException {
		assertThrows(SameAccountException.class, () -> serviceImpl.fundTransfer(sourceAccount, sourceAccount, 100),
				"Can't Tranfer fund to the same Account");
	}
//
	@Test
	@DisplayName("Account Not Found, If target Acount Number is wrong")
	public void testFundTransfer_AccountNotFound_shouldThrowException() throws NullPointerException {
		double amount = 100;
		assertThrows(NullPointerException.class, () -> serviceImpl.fundTransfer(sourceAccount, null, amount),
				"Account Not Found");
	}
//
	
//	
	@AfterEach
	@DisplayName("Transaction should Found, if any transaction takes place")
	public void transactionFound()throws NoTransactionFoundException {
		assertNotNull("If deposit, withdraw or fund Transfer takes place from source account ",
		serviceImpl.getAllTransactionDetails(sourceAccount));
	}
//
	@AfterAll
	public void tearDownAfterClass() throws Exception {
		//DELETE DATA
				eM.getTransaction().begin();
				
				//Lets find if the required data is present in the database table or not
//				Account acc1Del = eM.find(Account.class, 1);
//				Account acc2Del = eM.find(Account.class, 2);
				//Deleting the particular Employee
//				if(acc1Del!=null && acc2Del!=null) {
					eM.remove(sourceAccount);
					eM.remove(targetAccount);					
//				}
//				else
//					System.out.println("Employee not Available in the TAble");
				eM.getTransaction().commit();
	}

}
