package com.bankapp.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.cg.bankapp.beans.*;
import com.cg.bankapp.dao.*;
import com.cg.bankapp.exceptions.NoTransactionFoundException;
import com.cg.bankapp.exceptions.SameAccountException;
import com.cg.bankapp.service.*;
import com.cg.bankapp.util.*;

public class BankAppMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		//DATABASE SETUP
		//BankDatabase.setupDB();
		
		System.out.println(Color.BGWHITE + Color.TXTPURPLE + "BANK SERVER APPLICATION:- " + Color.RESET);

		Scanner keyboard = new Scanner(System.in);

		// Taking Bank Services
		BankServiceImpl bnkSrvImpl = new BankServiceImpl();

		// Finding Account as per Given Account Number
		BankDAOImpl findAcc = new BankDAOImpl();

		/**
		 * Since, Each Account belongs to Each customer, we're going to get the whole
		 * application's access only to the customer who enter their correct account number at
		 * very First before starting the application.
		 */
		Account accGotById = new Account();
		String strAccNum;
		int accNum = 0;
		do {
			System.out.print("Enter Account Number: ");

			try {
				strAccNum = keyboard.next();

				if (strAccNum.matches("\\d+")) {
					accNum = Integer.parseInt(strAccNum);

					accGotById = findAcc.getAccountById(accNum);

					System.out.println(Color.TXTYELLOW + "Welcome! " + accGotById.getCustomer().getcustomerName()
							+ " 😊" + Color.RESET);
				} else {
					System.out.println(Color.TXTBLUE + "Account Id Should be Number!" + Color.RESET);
					System.out.println("");
				}

			} catch (Exception err) {
				System.err.println(err);
				System.out.println(Color.TXTYELLOW + "Please Enter the Correct Account Number!" + Color.RESET);
				System.out.println("");
			}

			// Account Number will get 0 (by default) till account number doesn't fetch correctly
		} while (accGotById.getAccountBalance() == 0);

		int choice;
		do {
			choice = showMenu(keyboard);
			switch (choice) {
			case 1:
				System.out.println(Color.TXTYELLOW + accGotById.getCustomer().getcustomerName() + " Your Balance is: "
						+ bnkSrvImpl.showBalance(accGotById) + Color.RESET);
				break;

			case 2:
				double currAccBal = accGotById.getAccountBalance();

				do {
					try {
						System.out.print("Enter Amount to Deposit: ");
						double amount = keyboard.nextDouble();
						double updatedAccBal = bnkSrvImpl.deposit(accGotById, amount);

						if (currAccBal != updatedAccBal) {
							System.out.println(Color.TXTGREEN + amount + " Deposited Successfully" + Color.RESET);
							System.out.println(Color.TXTYELLOW + "New Balance: " + updatedAccBal + Color.RESET);
						}

					} catch (Exception err) {
						System.err.println(err);
						System.out.println(Color.TXTYELLOW + "Negative Amount not Allowed!" + Color.RESET);
						System.out.println("");
					}

				} while (currAccBal == accGotById.getAccountBalance());
				break;

			case 3:

				System.out.println(
						Color.TXTYELLOW + "Available Balance: " + bnkSrvImpl.showBalance(accGotById) + Color.RESET);

				do {
					currAccBal = accGotById.getAccountBalance();
					try {
						System.out.print("Enter Amount to Withdraw: ");
						double amount = keyboard.nextDouble();

						double newBal = bnkSrvImpl.withdraw(accGotById, amount);
						if (currAccBal != newBal)
							System.out.println(Color.TXTYELLOW + "New Balance: " + newBal + Color.RESET);
						else
							break;

					} catch (Exception err) {
						System.err.println(err);
						System.out.println(Color.TXTYELLOW + "Please Enter the Correct Amount" + Color.RESET);
						System.out.println("");
					}

				} while (accGotById.getAccountBalance() == currAccBal);
				break;

			case 4:

				Account targetAccount = new Account();
				double currTargetBal = targetAccount.getAccountBalance();
				do {

					if (targetAccount.getAccountBalance() == 0)
						System.out.print("Enter 2nd Account Number (To): ");
					try {
						strAccNum = keyboard.next();
						int targetAccNum = 0;
						if (strAccNum.matches("\\d+")) {
							targetAccNum = Integer.parseInt(strAccNum);

							if (targetAccNum == accNum)
								// Can't send Amount to the same account
								throw new SameAccountException("Can't Transfer Fund to the Same Account");

							targetAccount = findAcc.getAccountById(targetAccNum);
							System.out.println("");
							System.out.println(Color.TXTBLUE + "Note: Your're Transfering Money to --> "
									+ targetAccount.getCustomer().getcustomerName() + Color.RESET);
							double newTargetBal = 0;
							double amount = 0;
							do {

								try {
									System.out.print("Enter Amount to Transfer: ");
									amount = keyboard.nextDouble();
									newTargetBal = bnkSrvImpl.
											fundTransfer(accGotById, targetAccount, amount);

								} catch (Exception err) {
									System.err.println(err);
									System.out.println(
											Color.TXTYELLOW + "Please Enter the Correct Amount!" + Color.RESET);
									System.out.println("");
								}

							} while (currTargetBal == newTargetBal);

							if (currTargetBal != newTargetBal)
								System.out
										.println(Color.TXTGREEN + amount + " Transfered Successfully!!" + Color.RESET);

						} else {
							System.out.println(Color.TXTBLUE + "Account Id Should be Number!" + Color.RESET);
							System.out.println("");
						}

					} catch (Exception err) {
						System.err.println(err);
						System.out.println(Color.TXTYELLOW + "Please Enter the Correct Account Number!" + Color.RESET);
						System.out.println("");
					}

					// CustomerId will be 0 (by default) till account number doesn't fetch correctly
				} while (targetAccount.getAccountBalance() == 0);

				break;

			case 5:

				try {
					List<Transaction> transaction = bnkSrvImpl.getAllTransactionDetails(accGotById);

					boolean transacitonFound = false;
					int transactionCount = 0;

					for (int i = transaction.size() - 1; i >= 0 && transactionCount < 10; i--) {
						if (transaction.get(i) != null) {
							System.out.println(Color.TXTYELLOW + transaction.get(i) + Color.RESET);
							transacitonFound = true;
							transactionCount++;
						}
					}

					if (!transacitonFound)
						throw new NoTransactionFoundException("No Transaction Found");
				} catch (Exception err) {
					System.err.println(err);
					System.out.println(Color.TXTYELLOW + "No, Transaction Found!" + Color.RESET);
				}

				break;

			case 6:
				System.out.println(Color.TXTBLUE + "Thanks, for using my application!" + Color.RESET);
				break;

			default:
				break;
			}

		} while (choice != 6);
	}

	/*
	 * Since, This is a menu Driven Application, we letting customer to use this
	 * application by using menu Choice.
	 */
	public static int showMenu(Scanner keyboard) {
		int choice = 1;
		// This menu will appear again if customer enter the wrong choice.
		do {
			if (choice < 1 || choice > 6)
				System.out.println("Invalid Menu Choice");

			System.out.println("");
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Transfer Fund");
			System.out.println("5. Get Transaction Details (Last 10 Transactions)");
			System.out.println("6. Exit");
			System.out.println("");
			System.out.print("Enter Choice: ");

			choice = keyboard.nextInt();
		} while (choice < 1 || choice > 6);
		return choice;
	}
}
