package com.cg.bankapp.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;
import com.cg.bankapp.util.JPAUtil;

public class BankDAOImpl implements BankDAO {
	private static EntityManager eM = JPAUtil.getEntityManagerFactory().createEntityManager();

	@Override
	// Get the required Account as per User's Account Number
	public Account getAccountById(int accountId) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		Account account = eM.find(Account.class, accountId);

		boolean accountFound = false;

		if (account != null) {
			accountFound = save(account);
		}

		if (!accountFound) {
			throw new AccountNotFoundException("Account Not Found");
		}


		// If account has done any Previous Transaction, then it will get load
		// all the previous transactions
		// To read all Data from Transaction Table
		String transQuery = "select t from Transaction t";
		// to get all transactions of a particular account
		TypedQuery<Transaction> typedQuery = eM.createQuery(transQuery, Transaction.class);
		
		List<Transaction> transList = typedQuery.getResultList();
		for (Transaction allTrans : transList) {
			if(accountId == allTrans.getAccount().getAccountNumber())
				account.getTransaction().add(allTrans);
		}


		// Returning Account as per given account Number
		return account;

	}

	@Override
	public boolean save(Account account) {
		boolean accountStatus = false;
		if (account != null)
			accountStatus = true;

		return accountStatus;
	}

	@Override
	@Transactional
	public void updateBalanceAndTransaction(Account accGotById, double balance, double amount, String transType)
			throws SQLException, ClassNotFoundException {

		// TRANSACTION DETAIL ADDING
		Transaction transaction = new Transaction(amount, transType, accGotById);
		try {
			eM.getTransaction().begin();
			eM.persist(transaction);
			eM.getTransaction().commit();			
		} catch (PersistenceException e) {
			eM.getTransaction().rollback();
			throw e;
		}
		
		//Storing Transaction to the Account
		accGotById.getTransaction().clear();
		String transQuery = "select t from Transaction t";
		// to get all transactions of a particular account
		TypedQuery<Transaction> typedQuery = eM.createQuery(transQuery, Transaction.class);
		
		List<Transaction> transList = typedQuery.getResultList();
		for (Transaction allTrans : transList) {
			if(accGotById.getAccountNumber() == allTrans.getAccount().getAccountNumber())
				accGotById.getTransaction().add(allTrans);
		}

		// Updating Balance to the Account
		eM.getTransaction().begin();
		accGotById.setAccountBalance(balance);
		eM.getTransaction().commit();

	}

}