package com.cg.bankapp.service;

import java.sql.SQLException;
import java.util.List;
import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;


public interface BankService {
	public double showBalance(Account accGotById);
	public double deposit(Account accGotById, double amount) throws NegativeAmountException, SQLException, ClassNotFoundException;
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException, NegativeAmountException, ClassNotFoundException, SQLException;
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)throws InsufficientBalanceException, NegativeAmountException, SameAccountException, AccountNotFoundException, ClassNotFoundException, SQLException; 
	List<Transaction> getAllTransactionDetails(Account accGotById) throws NoTransactionFoundException;
}
