package com.cg.bankapp.service;

import java.util.List;
import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

//The BankService interface defines a set of methods for performing various banking operations.
public interface BankService {
	/**
	This method returns the balance of a given account.
	@param accGotById the account for which balance needs to be retrieved
	@return the balance of the account
	*/
	public double showBalance(Account accGotById);
	
	/**
	This method deposits a specified amount into a given account.
	@param accGotById the account in which amount needs to be deposited
	@param amount the amount to be deposited
	@throws NegativeAmountException if the amount is negative
	@return the updated balance of the account after deposit
	*/
	public double deposit(Account accGotById, double amount) throws NegativeAmountException;
	
	/**
	This method withdraws a specified amount from a given account.
	@param accGotById the account from which amount needs to be withdrawn
	@param amount the amount to be withdrawn
	@throws InsufficientBalanceException if the account balance is less than the requested amount
	@throws NegativeAmountException if the amount is negative
	@return the updated balance of the account after withdrawal
	*/
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException, NegativeAmountException;
	
	/**
	This method transfers a specified amount from the source account to the target account.
	@param sourceAccount the account from which amount needs to be transferred
	@param targetAccount the account to which amount needs to be transferred
	@param amount the amount to be transferred
	@throws InsufficientBalanceException if the source account balance is less than the requested amount
	@throws NegativeAmountException if the amount is negative
	@throws SameAccountException if both the source and target accounts are the same
	@throws AccountNotFoundException if the source or target account is not found
	@return the updated balance of the source account after transfer
	*/
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)throws InsufficientBalanceException, NegativeAmountException, SameAccountException, AccountNotFoundException; 
	
	/**
	This method returns all the transaction details of a given account.
	@param accGotById the account for which transaction details need to be retrieved
	@throws NoTransactionFoundException if no transactions are found for the account
	@return a list of all the transaction details of the account
	*/
	List<Transaction> getAllTransactionDetails(Account accGotById) throws NoTransactionFoundException;
}
