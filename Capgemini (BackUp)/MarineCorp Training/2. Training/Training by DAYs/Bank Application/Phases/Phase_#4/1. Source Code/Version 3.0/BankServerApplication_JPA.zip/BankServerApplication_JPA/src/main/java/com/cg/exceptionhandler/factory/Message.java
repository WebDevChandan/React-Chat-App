package com.cg.exceptionhandler.factory;

import java.util.Map;

public class Message extends Actions{

	private String smsTo;
	private String smsMessage;

	// constructor
	public Message(Map<String, String> mp) {
		this.smsTo = mp.get("to");
		this.smsMessage = mp.get("sms_body");
	}

	@Override
	public void perform() {
		System.out.println(this);
	}

	@Override
	public String toString() {
		return "SendMessage [smsTo=" + smsTo + ", smsMessage=" + smsMessage + "]";
	}

}
