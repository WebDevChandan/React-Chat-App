package com.cg.bankapp.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.transaction.Transactional;


@Entity
@Table
public class Transaction {
	@Id
	@Column(name="ID",nullable = false)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="transId_generator")
	@SequenceGenerator(name="transId_generator", initialValue = 1001, allocationSize = 1, sequenceName = "transId_seq")
	private int transactionId;
	
	@Column(name="TransactionType")
	String transactionType;
	
	@Column(name="Amount")
	double amount;
	
	@ManyToOne
	Account account;
	
	public Account getAccount() {
		return account;
	}

	public Transaction() {
	}

	public Transaction( double amountTranf, String transType, Account account){
		this.amount=amountTranf;
		this.transactionType=transType;
		this.account = account;
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType + ", amount=" + amount   + "]";
	}
	
}
