package com.cg.exceptionhandler.handler;

public class NegativeAmountException {

}
