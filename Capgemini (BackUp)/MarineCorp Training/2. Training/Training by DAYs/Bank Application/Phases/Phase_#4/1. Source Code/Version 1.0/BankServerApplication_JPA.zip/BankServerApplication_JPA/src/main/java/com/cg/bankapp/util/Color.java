package com.cg.bankapp.util;

public interface Color {
	static final String RESET = "\u001B[0m";
	static final String BGWHITE = "\u001B[47m";
	static final String TXTBLACK = "\u001B[30m";
	static final String TXTGREEN = "\u001B[32m";
	static final String TXTBLUE = "\u001B[34m";
	static final String TXTPURPLE = "\u001B[35m";
	static final String TXTYELLOW  = "\u001B[33m";
}
