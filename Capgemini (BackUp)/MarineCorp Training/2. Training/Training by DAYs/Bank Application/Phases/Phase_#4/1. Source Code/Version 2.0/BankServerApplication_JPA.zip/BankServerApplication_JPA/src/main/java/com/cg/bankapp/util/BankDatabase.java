package com.cg.bankapp.util;

import javax.persistence.EntityManager;


public class BankDatabase {
	private static EntityManager eM;

	private BankDatabase() {
		
	}
	static {
		eM = JPAUtil.getEntityManagerFactory().createEntityManager();
	}
	
	public static void setupDB() {
			BankCrudOperation.createAccount(eM);
	}
	

	public static EntityManager getEntityManager() {
		return eM;
	}

//	public static void main(String[] args) {
//		new BankDatabase();
//	}
}
