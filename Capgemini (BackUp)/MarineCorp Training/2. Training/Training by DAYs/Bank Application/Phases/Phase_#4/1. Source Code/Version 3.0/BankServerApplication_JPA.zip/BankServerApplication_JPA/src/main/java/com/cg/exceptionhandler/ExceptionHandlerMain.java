package com.cg.exceptionhandler;

import com.cg.exceptionhandler.client.Client;

public class ExceptionHandlerMain {
	public static void main(String[] args) {
		Client obj1 = new Client();
		Client obj2 = new Client();
		
		obj1.readXMLUsingDOM();
	}
}
