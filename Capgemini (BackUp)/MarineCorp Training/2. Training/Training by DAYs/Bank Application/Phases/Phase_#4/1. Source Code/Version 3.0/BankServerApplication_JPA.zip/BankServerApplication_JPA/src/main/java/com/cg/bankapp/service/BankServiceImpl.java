package com.cg.bankapp.service;

import java.util.List;
import com.cg.bankapp.beans.*;
import com.cg.bankapp.beans.Transaction;
import com.cg.bankapp.dao.BankDAOImpl;
import com.cg.bankapp.exceptions.*;
import com.cg.bankapp.util.Color;

/**
 * The BankServiceImpl class implements the BankService interface and provides
 * the implementation of all the operations required for bank account
 * management, such as showing account balance, depositing, withdrawing, and
 * transferring funds between accounts. It also provides the functionality to
 * get all the transaction details associated with a particular account.
 */
public class BankServiceImpl implements BankService {

	/**
	 * The showBalance method takes an Account object as a parameter and returns the
	 * balance associated with it.
	 * 
	 * @param accGotById An Account object that represents the account for which the
	 *                   balance is to be displayed.
	 * @return A double value representing the account balance.
	 */
	@Override
	public double showBalance(Account accGotById) {
		double balance = 0.0;
		balance = accGotById.getAccountBalance();

		return balance;
	}

	/**
	 * The deposit method takes an Account object and an amount as parameters and
	 * performs a deposit operation on the account.
	 * 
	 * @param accGotById An Account object representing the account to which the
	 *                   deposit is to be made.
	 * @param amount     A double value representing the amount to be deposited.
	 * @return A double value representing the updated account balance.
	 * @throws NegativeAmountException Thrown when the deposit amount is negative.
	 */
	@Override
	public double deposit(Account accGotById, double amount) throws NegativeAmountException {
		BankDAOImpl updateAccBal = new BankDAOImpl();

		double balance = accGotById.getAccountBalance();
		balance += amount;

		if (amount < 0)
			throw new NegativeAmountException("Amount Can't be Negative");
		else {
			// Update the Account Balance
			updateAccBal.updateBalanceAndTransaction(accGotById, balance, amount, "\"Credit\"");

		}

		// Getting The updated account Balance from the Account Object
		return balance;
	}

	/**
	 * This method performs a withdrawal operation for a given account with the
	 * specified amount.
	 * @param accGotById The account from which the withdrawal needs to be made.
	 * @param amount     The amount to be withdrawn.
	 * @return The updated account balance after the withdrawal.
	 * @throws InsufficientBalanceException If the account balance is less than the withdrawal amount.
	 * @throws NegativeAmountException      If the withdrawal amount is negative.
	 */
	@Override
	public double withdraw(Account accGotById, double amount)
			throws InsufficientBalanceException, NegativeAmountException {
		BankDAOImpl updateAccBal = new BankDAOImpl();

		double balance = accGotById.getAccountBalance();
		if (amount > balance)
			throw new InsufficientBalanceException("Insufficient Balance");
		else if (amount < 0)
			throw new NegativeAmountException("Amount Can't be Negative");
		else {
			balance -= amount;

			// Update Account Balance
			updateAccBal.updateBalanceAndTransaction(accGotById, balance, amount, "\"Debited\"");
			System.out.println(Color.TXTGREEN + amount + " withdrawl Successfully!" + Color.RESET);

		}

		return balance;
	}

	/*
	 * This method performs a fund transfer operation from the source account to the
	 * target account with the specified amount.
	 * @param sourceAccount The account from which the fund transfer needs to be
	 * made.
	 * @param targetAccount The account to which the fund transfer needs to be made.
	 * @param amount The amount to be transferred.
	 * @return The updated account balance of the target account after the fund transfer.
	 * @throws InsufficientBalanceException If the source account balance is less
	 * than the transfer amount.
	 * @throws NegativeAmountException If the transfer amount is negative.
	 * @throws SameAccountException If the source and target accounts are the same.
	 * @throws AccountNotFoundException If either the source or target account is
	 * not found.
	 */
	@Override
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)
			throws InsufficientBalanceException, NegativeAmountException, SameAccountException,
			AccountNotFoundException {
		BankDAOImpl updateAccBal = new BankDAOImpl();

		if (sourceAccount == targetAccount)
			throw new SameAccountException("Can't trsfer Fund to the Same Account");

		double sourceAccountBal = sourceAccount.getAccountBalance();
		double targetAccountBal = targetAccount.getAccountBalance();

		if (amount > sourceAccountBal)
			throw new InsufficientBalanceException("Insufficient Balance");
		else if (amount < 0)
			throw new NegativeAmountException("Amount Can't be negative");
		else {
			sourceAccountBal -= amount;
			targetAccountBal += amount;


			updateAccBal.updateBalanceAndTransaction(targetAccount, targetAccountBal, amount, "\"Credited\"");

			// Updating Target Account & Source Account Balance
			updateAccBal.updateBalanceAndTransaction(sourceAccount, sourceAccountBal, amount, "\"Debited\"");
		}

		return targetAccountBal;
	}

	@Override
	public List<Transaction> getAllTransactionDetails(Account accGotById) throws NoTransactionFoundException {

		if (accGotById.getTransaction().isEmpty())
			throw new NoTransactionFoundException("No Transaction Found");

		return accGotById.getTransaction();
	}

}
