package com.cg.exceptionhandler;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class MyStax {
	public static void main(String[] args) throws FileNotFoundException, XMLStreamException {
		// Object of the class which helps on reading tags
		XMLInputFactory factory = XMLInputFactory.newInstance();

		// Initializing the handler to access the tags in the XML file
		XMLEventReader eventReader = factory.createXMLEventReader(new FileReader("Exceptions.xml"));

		String currentElement = "";

		// Checking the availability of the next tag
		while (eventReader.hasNext()) {
			// Event is actually the tag . It is of 3 types
			// <name> = StartEvent
			// </name> = EndEvent
			// data between the StartEvent and the EndEvent
			// which is Characters Event
			XMLEvent event = eventReader.nextEvent();
			
			System.out.println(event.getEventType());
			
			switch (event.getEventType()) {
			case XMLStreamConstants.START_ELEMENT:
				StartElement startElement = event.asStartElement();
				currentElement = startElement.getName().getLocalPart();
				
				switch (currentElement) {
				case "module":
					String moduleName = startElement.getAttributeByName(new QName("name")).getValue();
					System.out.println("Module name: " + moduleName);
					break;
				case "exception":
					String exceptionName = startElement.getAttributeByName(new QName("name")).getValue();
					System.out.println("Exception name: " + exceptionName);
					break;
				case "actions":
					System.out.println("Actions:");
					break;
				case "sms":
					String smsTo = startElement.getAttributeByName(new QName("to")).getValue();
					String smsBody = startElement.getAttributeByName(new QName("sms_body")).getValue();
					System.out.println("Send SMS to: " + smsTo + ", message: " + smsBody);
					break;
				case "email":
					String emailTo = startElement.getAttributeByName(new QName("to")).getValue();
					String emailBody = startElement.getAttributeByName(new QName("emailbody")).getValue();
					System.out.println("Send email to: " + emailTo + ", message: " + emailBody);
					break;
				case "log":
					String logName = startElement.getAttributeByName(new QName("name")).getValue();
					String logFile = startElement.getAttributeByName(new QName("file")).getValue();
					System.out.println("Write to log " + logName + ", file: " + logFile);
					break;
				}
				break;
			case XMLStreamConstants.END_ELEMENT:
				currentElement = "";
				break;
			}
		}
	}
}
