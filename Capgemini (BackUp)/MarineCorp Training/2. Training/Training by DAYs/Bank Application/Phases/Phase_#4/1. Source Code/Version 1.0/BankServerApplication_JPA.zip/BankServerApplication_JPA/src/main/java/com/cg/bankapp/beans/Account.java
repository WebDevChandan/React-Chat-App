package com.cg.bankapp.beans;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table
public class Account{
	@Id
	@Column(name="acc_ID",  nullable = false)
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="accId_generator")
	@SequenceGenerator(name="accId_generator", initialValue = 123450, allocationSize = 1, sequenceName = "accId_seq")
	private int accountNumber;	
	
	@Column(name="AccountType")
	private String accountType;
	
	@Column(name="AccountBalance")
	private double accountBalance;
	
	//By default, This annotation will create a Foreign key to Account Class
	//Default name of the Foreign Key created would be:
	//	- name of Reference Entity__Column name of primary key of Reference Entity 
	//Hence, default foreign key name would be "customer_cus_id"
	//In order to give custom name of foreign key, we need to use @JoinColumn
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Cus_ID")
	private Customer customer;
	
	
	@OneToMany(targetEntity = Transaction.class, cascade = CascadeType.ALL)
	@JoinColumn(name="at_fk", referencedColumnName = "acc_ID")
	static List<Transaction> transaction = new ArrayList<Transaction>();
	
	
	public Account() {}
	
	public Account(Customer cust, double accBal) {
		this.customer = cust;
		this.accountBalance=accBal;
		this.accountType="Salary";
	}
	
	

	public int getAccountNumber() {
		return accountNumber;
	}

	
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public String getAccountType() {
		return accountType;
	}


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Transaction> getTransaction() {
		return transaction;
	}


	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", accountType="
				+ accountType + ", customer=" + customer + ", transaction="+ transaction +"]";
	}

	
}
