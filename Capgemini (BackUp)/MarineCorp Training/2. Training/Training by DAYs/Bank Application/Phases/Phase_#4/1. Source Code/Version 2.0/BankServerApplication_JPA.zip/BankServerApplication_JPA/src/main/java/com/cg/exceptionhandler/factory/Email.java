package com.cg.exceptionhandler.factory;

import java.util.Map;

public class Email extends Actions{

	private String emailTo;
	private String emailMessage;

	// constructor
	public Email(Map<String, String> mp) {
		this.emailTo = mp.get("to");
		this.emailMessage = mp.get("emailbody");
	}

	@Override
	public void perform() {
		System.out.println(this);
	}

	@Override
	public String toString() {
		return "SendEmail [emailTo=" + emailTo + ", emailMessage=" + emailMessage + "]";
	}
}
