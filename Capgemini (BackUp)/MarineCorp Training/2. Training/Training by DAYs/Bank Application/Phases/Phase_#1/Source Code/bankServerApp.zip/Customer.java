package com.bankapp.server;

public class Customer {
	public int customerId;
	private String customerName;
	
	public Customer(){
		
	}

	public Customer(int custId, String custName){
		this.customerId=custId;
		this.customerName=custName;
	}

	public String  getcustomerName() {
		return customerName;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
	}
	
}
