package com.bankapp.server;

public class FindAccount implements BankDao {
	
	//Get the required Account as per User's Account Number
	public Account getAccountById(Account account[], int accountId) {
		boolean accountFound = false;
		int index=0;
		
		for(int i=0; i<account.length; i++) {
			if(account[i].getAccountNumber() == accountId) {
				index= i;
				accountFound = true;
				break;
			}
		}
		if(!accountFound) 
			System.err.println("Account Not Found");
		
		return account[index]; 
	}
}
