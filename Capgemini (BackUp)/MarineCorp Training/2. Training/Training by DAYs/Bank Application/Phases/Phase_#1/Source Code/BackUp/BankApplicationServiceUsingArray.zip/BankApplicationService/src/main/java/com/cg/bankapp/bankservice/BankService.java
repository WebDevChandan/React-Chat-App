package com.cg.bankapp.bankservice;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankService {
	public double showBalance(Account accGotById);
	public double deposit(Account accGotById, double amount);
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException;
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount)throws InsufficientBalanceException;
	Transaction[] getAllTransactionDetails(Account AccGotById);
}
