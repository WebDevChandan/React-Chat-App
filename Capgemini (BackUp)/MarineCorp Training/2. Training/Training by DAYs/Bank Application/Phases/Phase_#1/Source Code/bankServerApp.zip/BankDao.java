package com.bankapp.server;

public interface BankDao {
//	public boolean save(Account account);
	public Account getAccountById(Account account[], int accountId);
}
