package com.bankapp.server;

public class BankServiceImpl implements BankService{
	static int sourceTransactionCount =0;		
	
	@Override
	public double showBalance(Account accGotById) {
		double balance = 0.0;
		balance = accGotById.getAccountBalance();
		 return balance;		
	}

	@Override
	public double deposit(Account accGotById, double amount) {
		double balance = accGotById.getAccountBalance();
		balance += amount;
		accGotById.setAccountBalance(balance);
		System.out.println( amount + " Deposited Successfully!");
		return balance;
	}

	@Override
	public double withdraw(Account accGotById, double amount) {
		double balance = accGotById.getAccountBalance();
		balance -= amount;
		
		accGotById.setAccountBalance(balance);
		
		System.out.println(amount + " withdrawl Successfully!");
		return balance;
	}

	@Override
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount) {
		double sourceAccountBal = sourceAccount.getAccountBalance();
		double targetAccountBal = targetAccount.getAccountBalance();
		
		sourceAccountBal -=amount;
		targetAccountBal +=amount;
		
		//Generating a random number for transactionId
		int sourceTransId = (int)Math.floor(Math.random()*1000000);
		int targetTransId = (int)Math.floor(Math.random()*1000000);
		
		//Storing SourceAccount's Transaction Details
		sourceAccount.transaction[sourceTransactionCount] = new Transaction(sourceTransId, amount, "To", targetAccount.customer.getcustomerName());
		sourceTransactionCount++;
		
		//Since, Target Account might get change, hence we can't make it static.			
		int targetTransactionCount=0;
		
		//Storing TargetAccount's Transaction Details
		for(int i=targetTransactionCount; i<targetAccount.transaction.length; i++) {
			if(targetAccount.transaction[i]==null) {
				targetAccount.transaction[i] = new Transaction(targetTransId , amount, "From", sourceAccount.customer.getcustomerName());
				break;
			}
		}
		
		
		sourceAccount.setAccountBalance(sourceAccountBal);
		targetAccount.setAccountBalance(targetAccountBal);

		return amount;
	}

	@Override
	public Transaction[] getAllTransactionDetails(Account accGotById) {
		
		return accGotById.transaction;
	}


}
