package com.bankapp.server;

import java.util.*;

public class App extends BankDatabase {

	public static void main(String[] args) {
		System.out.println("BANK SERVER APPLICATION:- ");

		Scanner keyboard = new Scanner(System.in);

		BankDatabase bDB = new BankDatabase();

		bDB.account[0] = new Account(123450, new Customer(101, "Chandan"), 200.0);
		bDB.account[1] = new Account(123456, new Customer(201, "Aditya"), 100.0);
		bDB.account[2] = new Account(123457, new Customer(301, "Chandan"), 0.0);
		bDB.account[3] = new Account(123458, new Customer(401, "Chandan"), 9.5);
		bDB.account[4] = new Account(123459, new Customer(501, "Chandan"), 0.0);
		bDB.account[5] = new Account(123451, new Customer(601, "Chandan"), 11.0);
		bDB.account[6] = new Account(123452, new Customer(701, "Chandan"), 0.0);
		bDB.account[7] = new Account(123453, new Customer(801, "Chandan"), 0.0);
		bDB.account[8] = new Account(123454, new Customer(901, "Chandan"), 0.0);
		bDB.account[9] = new Account(123455, new Customer(001, "Chandan"), 0.0);

		

		// Taking Bank Services
		BankServiceImpl bnkSrvImpl = new BankServiceImpl();
		
		//Finding Account as per Given Account Number
		FindAccount findAcc = new FindAccount();

		int choice; 
		do {
			choice = showMenu(keyboard);
			switch (choice) {
			case 1:
				System.out.print("Enter Account Number: ");
				
				int accNum = keyboard.nextInt();
				Account accGotById = findAcc.getAccountById(bDB.account, accNum);

				System.out.println(accGotById.customer.getcustomerName() +" Your Balance:" + bnkSrvImpl.showBalance(accGotById));
				break;

			case 2:
				System.out.print("Enter Account Number: ");
				
				accNum = keyboard.nextInt();
				accGotById = findAcc.getAccountById(bDB.account, accNum);
				
				System.out.print("Enter Amount to Deposit: ");
				double amount = keyboard.nextDouble();
				
				System.out.println( "New Balance: " + bnkSrvImpl.deposit(accGotById, amount));
				break;

			case 3:
				System.out.print("Enter Account Number: ");
				accNum = keyboard.nextInt();
				accGotById = findAcc.getAccountById(bDB.account, accNum);
				
				System.out.println("Available Balance: " + bnkSrvImpl.showBalance(accGotById));
				
				System.out.print("Enter Amount to Withdraw: ");
				amount = keyboard.nextDouble();
				
				System.out.println( "New Balance: " + bnkSrvImpl.withdraw(accGotById, amount));
				break;

			case 4:

				System.out.print("Enter Account Number-1(From): ");
				accNum = keyboard.nextInt();
				Account sourceAccount = findAcc.getAccountById(bDB.account, accNum);
				

				System.out.print("Enter Account Number-2(To): ");
				accNum = keyboard.nextInt();
				Account targetAccount = findAcc.getAccountById(bDB.account, accNum);
				
				System.out.println("");
				System.out.println("Note: Your're Transfering Money to --> " + targetAccount.customer.getcustomerName());
				
				System.out.print("Enter Amount to Transfer: ");
				amount = keyboard.nextDouble();
				
				System.out.println(bnkSrvImpl.fundTransfer(sourceAccount, targetAccount, amount) + " Transfered Successfully!!");
				
				break;
				
			case 5:
				System.out.print("Enter Account Number: ");
				
				accNum = keyboard.nextInt();
				accGotById = findAcc.getAccountById(bDB.account, accNum);
				
				Transaction[] transaction = bnkSrvImpl.getAllTransactionDetails(accGotById);
				
				boolean transacitonFound = false;
				
				for(int i=0; i<transaction.length;i++) {
					if(transaction[i]!=null) {						
						System.out.println(transaction[i]);
						transacitonFound = true;
					}
				}

				if(!transacitonFound)
				System.out.println("No, Transaction Found");
				
				//This will print all 10 transactions
				//System.out.println(Arrays.toString(transaction));
				break;
				
			case 6:
				System.out.println("Thanks, for using my application!");
				break;
			default:
				break;
			}
			
		}while(choice!=6);
	}

	public static int showMenu(Scanner keyboard) {
		int choice;
		do {
			System.out.println("");
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Transfer Fund");
			System.out.println("5. Get Transaction Details (Last 10 Transactions)");
			System.out.println("6. Exit");
			System.out.println("");
			System.out.print("Enter Choice: ");

			choice = keyboard.nextInt();
		} while (choice < 1 || choice > 6);
		return choice;
	}

}