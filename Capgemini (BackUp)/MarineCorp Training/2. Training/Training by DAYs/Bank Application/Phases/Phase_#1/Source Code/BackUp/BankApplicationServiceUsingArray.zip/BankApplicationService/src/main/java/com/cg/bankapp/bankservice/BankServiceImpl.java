package com.cg.bankapp.bankservice;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.beans.Transaction;
import com.cg.bankapp.util.*;
import com.cg.bankapp.exceptions.*;

public class BankServiceImpl implements BankService{
	static int sourceTransactionCount =0;		
	Color clr = new Color();
	
	@Override
	public double showBalance(Account accGotById) {
		double balance = 0.0;
		balance = accGotById.getAccountBalance();
		 return balance;		
	}

	@Override
	public double deposit(Account accGotById, double amount) {
		double balance = accGotById.getAccountBalance();
		balance += amount;
		accGotById.setAccountBalance(balance);
		
		//Storing Deposit as Transaction
		int depoTransId = (int)Math.floor(Math.random()*1000000);
		
		accGotById.transaction[sourceTransactionCount] = new Transaction(depoTransId , amount, "Credited");
		sourceTransactionCount++;
		
		return balance;
	}

	@Override
	public double withdraw(Account accGotById, double amount) throws InsufficientBalanceException{

		double balance = accGotById.getAccountBalance();
		try {
			if(amount>balance)
				throw new InsufficientBalanceException("Insufficient Balance");
			else {				
				balance -= amount;
				
				accGotById.setAccountBalance(balance);
				System.out.println(clr.TXTGREEN +amount + " withdrawl Successfully!" + clr.RESET);
				
				//Storing withdraw as Transaction
				int withDrawTransId = (int)Math.floor(Math.random()*1000000);
				accGotById.transaction[sourceTransactionCount] = new Transaction(withDrawTransId , amount, "Debited");
				sourceTransactionCount++;
			}
				
		}catch(Exception err) {
			System.err.println("Withdrawl Unsuccessfull!");
			System.out.println(err);
		}
		
		return balance;
	}

	@Override
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount) throws InsufficientBalanceException {
		double sourceAccountBal = sourceAccount.getAccountBalance();
		double targetAccountBal = targetAccount.getAccountBalance();
		
		
		try {
			if(amount>sourceAccountBal)
				throw new InsufficientBalanceException("Insufficient Balance");
			else {				
				sourceAccountBal -=amount;
				targetAccountBal +=amount;
				
				//Generating a random number as transactionId  for Source Account
				int sourceTransId = (int)Math.floor(Math.random()*1000000);
				
				//Storing SourceAccount's Transaction Details
				sourceAccount.transaction[sourceTransactionCount] = new Transaction(sourceTransId, amount, "Debited");
				sourceTransactionCount++;
				
				
				
				sourceAccount.setAccountBalance(sourceAccountBal);
				targetAccount.setAccountBalance(targetAccountBal);
			}
		}catch(Exception err) {
			System.err.println("Withdrawl Unsuccessfull!");
			System.err.println(err);
			
		}
			
		return targetAccountBal;
	}

	@Override
	public Transaction[] getAllTransactionDetails(Account accGotById) {
		
		return accGotById.getTransaction();
	}
}
