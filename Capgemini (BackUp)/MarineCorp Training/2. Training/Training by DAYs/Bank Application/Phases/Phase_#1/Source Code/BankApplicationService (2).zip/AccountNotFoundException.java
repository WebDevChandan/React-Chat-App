package com.bankapp.BankServerApplication;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException(String str){
		super(str);
	}
}
