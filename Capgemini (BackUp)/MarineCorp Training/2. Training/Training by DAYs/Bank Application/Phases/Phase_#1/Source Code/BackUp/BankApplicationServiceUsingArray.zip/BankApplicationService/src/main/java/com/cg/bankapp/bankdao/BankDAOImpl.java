package com.cg.bankapp.bankdao;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public class BankDAOImpl implements BankDAO{
	
	@Override
	//Get the required Account as per User's Account Number
	public Account getAccountById(Account account[], int accountId) throws AccountNotFoundException{
		boolean accountFound = false;
		int index=0;
		
		for(int i=0; i<account.length; i++) {
			if(account[i].getAccountNumber() == accountId) {
				index= i;
				accountFound = true;
				break;
			}
		}
		if(!accountFound) {
			throw new AccountNotFoundException("Account Not Found");
		}
			
		
		return account[index]; 
	}
	

	@Override
	public boolean save(Account account) {
		return false;
	}
}