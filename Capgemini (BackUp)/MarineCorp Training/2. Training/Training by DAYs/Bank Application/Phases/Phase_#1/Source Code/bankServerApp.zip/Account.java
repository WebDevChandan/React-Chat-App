package com.bankapp.server;

import java.util.Arrays;

public class Account{
	private int accountNumber;	
	private double accountBalance;
	private String accountType;
	
	Customer customer = new Customer();
	Transaction transaction[] = new Transaction[10];
	
	public Account() {
		
	}
	
	public Account(int accNum, Customer cust, double accBal) {
		this.accountNumber=accNum;
		this.customer = cust;
		this.accountBalance=accBal;
		this.accountType="Salary";
	}
	
	

	public int getAccountNumber() {
		return accountNumber;
	}


	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountType() {
		return accountType;
	}


	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Transaction[] getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", accountType="
				+ accountType + ", customer=" + customer + ", transaction=" + Arrays.toString(transaction) + "]";
	}

	
}
