import java.util.Scanner;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.SameAccountException;
import com.cg.bankapp.util.*;
import com.cg.bankapp.bankservice.*;
import com.cg.bankapp.bankdao.*;

public class BankAppMain {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Initializing instance of color class to access all defined colors.
		Color clr = new Color();
		
		System.out.println(clr.BGWHITE + clr.TXTPURPLE + "BANK SERVER APPLICATION:- " + clr.RESET);

		Scanner keyboard = new Scanner(System.in);

		// Getting Account DataBase from BankDatabase
		BankDatabase bDb = new BankDatabase();
		Account getAccDb[] = bDb.getAccountDb();

		// Taking Bank Services
		BankServiceImpl bnkSrvImpl = new BankServiceImpl();

		// Finding Account as per Given Account Number
		BankDAOImpl findAcc = new BankDAOImpl();

		
		/**
		 * Since, Each Account belongs to Each customer, we're going to get the
		 * whole application's access only to one customer who enter their 
		 * account number at First.
		 */
		Account accGotById = new Account();
		int accNum = 0;
		
		do {
				System.out.print("Enter Account Number: ");
				
			try {
				accNum = keyboard.nextInt();
				accGotById = findAcc.getAccountById(getAccDb, accNum);
				
				
				System.out.println(clr.TXTYELLOW + "Welcome! " + accGotById.customer.getcustomerName() + " 😊" + clr.RESET);
				
			} catch (Exception err) {
				System.err.println(err);
				System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
				System.out.println("");
			}
			
			//CustomerId will be 0 (by default) till account number doesn't fetch correctly
		}while(accGotById.customer.customerId==0);
		
		

		int choice;
		do {
			choice = showMenu(keyboard);
			switch (choice) {
			case 1:
				System.out.println(clr.TXTYELLOW + accGotById.customer.getcustomerName() + " Your Balance is: "
						+ bnkSrvImpl.showBalance(accGotById) + clr.RESET);
				break;

			case 2:

				System.out.print("Enter Amount to Deposit: ");
				double amount = keyboard.nextDouble();

				System.out.println(clr.TXTGREEN + amount + " Deposited Successfully" + clr.RESET);
				System.out.println(clr.TXTYELLOW + "New Balance: " + bnkSrvImpl.deposit(accGotById, amount) + clr.RESET);
				break;

			case 3:
				
					System.out.println(clr.TXTYELLOW + "Available Balance: " + bnkSrvImpl.showBalance(accGotById) + clr.RESET);
					try {
					System.out.print("Enter Amount to Withdraw: ");
					amount = keyboard.nextDouble();
					
					double currBal = accGotById.getAccountBalance();
					double newBal = bnkSrvImpl.withdraw(accGotById, amount);
					if(currBal!=newBal)
						System.out.println( clr.TXTYELLOW + "New Balance: " + newBal + clr.RESET);
					else break;
					
				}catch(Exception err) {
					System.err.println(err);
					System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
					break;
				}
				break;

			case 4:

				Account targetAccount = new Account();
				do {	
						if(targetAccount.customer.customerId==0)
							System.out.print("Enter 2nd Account Number (To): ");
					try {						
						int targetAccNum = keyboard.nextInt();
						if(targetAccNum == accNum)
							//Can't send Amount to the same account
							throw new SameAccountException("Can't Transfer Fund to the Same Account");
							
						targetAccount = findAcc.getAccountById(getAccDb, targetAccNum);
									
						System.out.println("");
						System.out.println(clr.TXTBLUE + "Note: Your're Transfering Money to --> " + targetAccount.customer.getcustomerName() + clr.RESET);
						
						System.out.print("Enter Amount to Transfer: ");
						amount = keyboard.nextDouble();
						
						double currTargetBal = targetAccount.getAccountBalance();
						double newTargetBal = bnkSrvImpl.fundTransfer(accGotById, targetAccount, amount);
						
						if(currTargetBal!=newTargetBal)
							System.out.println(clr.TXTGREEN + amount+ " Transfered Successfully!!" + clr.RESET);
						else
							break;
						
					}catch(Exception err) {
						System.err.println(err);
						System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
						System.out.println("");
					}
					
					//CustomerId will be 0 (by default) till account number doesn't fetch correctly
				}while(targetAccount.customer.customerId==0);
				
				break;
				
			case 5:
				
				try {
					Transaction[] transaction = bnkSrvImpl.getAllTransactionDetails(accGotById);
					
					boolean transacitonFound = false;
					
					for(int i=transaction.length-1; i>=0;i--) {
						if(transaction[i]!=null) {						
							System.out.println(clr.TXTYELLOW + transaction[i] + clr.RESET);
							transacitonFound = true;
						}
					}
					
					if(!transacitonFound)
						System.out.println(clr.TXTBLUE + "No, Transaction Found!"+ clr.RESET);					
				}catch(Exception err) {
					System.err.println(err);
					System.out.println(clr.TXTYELLOW + "Please Enter the Correct Account Number!" + clr.RESET);
				}
				
				//This will print all 10 transactions
				//System.out.println(Arrays.toString(transaction));
				break;

			case 6:
				System.out.println(clr.TXTBLUE + "Thanks, for using my application!" + clr.RESET);
				break;
			default:
				break;
			}

		} while (choice != 6);
	}
	

	/*
	 * Since, This is a menu Driven Application, we letting customer to use this application by using menu Choice.
	 * */
	public static int showMenu(Scanner keyboard) {
		int choice;
		//This menu will appear again if customer enter the wrong choice. 
		do {
			System.out.println("");
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Transfer Fund");
			System.out.println("5. Get Transaction Details (Last 10 Transactions)");
			System.out.println("6. Exit");
			System.out.println("");
			System.out.print("Enter Choice: ");

			choice = keyboard.nextInt();
		} while (choice < 1 || choice > 6);
		return choice;
	}
}
