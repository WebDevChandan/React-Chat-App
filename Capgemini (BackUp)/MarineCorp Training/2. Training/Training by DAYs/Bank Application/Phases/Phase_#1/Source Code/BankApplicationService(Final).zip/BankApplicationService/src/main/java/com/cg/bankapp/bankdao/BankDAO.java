package com.cg.bankapp.bankdao;

import com.cg.bankapp.beans.*;
import com.cg.bankapp.exceptions.*;

public interface BankDAO {
	public boolean save(Account account);
	public Account getAccountById(Account account[], int accountId) throws AccountNotFoundException;
}

