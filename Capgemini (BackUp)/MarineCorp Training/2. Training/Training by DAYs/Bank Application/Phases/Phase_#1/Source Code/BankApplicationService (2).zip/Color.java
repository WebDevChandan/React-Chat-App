package com.bankapp.BankServerApplication;

public class Color {
	public String RESET;
	public String BGWHITE;
	public String TXTBLACK;
	public String TXTGREEN;
	public String TXTBLUE;
	public String TXTPURPLE;
	public String TXTYELLOW;
	
	public Color() {
		BGWHITE ="\u001B[47m";
		 RESET  = "\u001B[0m";
		 TXTBLACK = "\u001B[30m";
		 TXTGREEN = "\u001B[32m";
		 TXTBLUE = "\u001B[34m";
		 TXTPURPLE = "\u001B[35m";
		 TXTYELLOW = "\u001B[33m";
	}
}
