package com.cg.bankapp.util;
import com.cg.bankapp.beans.*;

public class BankDatabase {
	 Account accountDb[];
	
	public BankDatabase() {		
		accountDb = new Account[10];
		
		accountDb[0] = new Account(123450, new Customer(101, "Chandan"), 1000.0);
		accountDb[1] = new Account(123456, new Customer(201, "Aditya"), 200.0);
		accountDb[2] = new Account(123457, new Customer(301, "Mayur"), 300.0);
		accountDb[3] = new Account(123458, new Customer(401, "Vishal"), 400.0);
		accountDb[4] = new Account(123459, new Customer(501, "Amar"), 500.0);
		accountDb[5] = new Account(123451, new Customer(601, "Misha"), 60.0);
		accountDb[6] = new Account(123452, new Customer(701, "Malhar"), 700.0);
		accountDb[7] = new Account(123453, new Customer(801, "Amar"), 400.0);
		accountDb[8] = new Account(123454, new Customer(901, "Ankiet"), 250.0);
		accountDb[9] = new Account(123455, new Customer(001, "Gaurav"), 550.0);
		
	}

	public  Account[] getAccountDb() {
		return accountDb;
	}

}