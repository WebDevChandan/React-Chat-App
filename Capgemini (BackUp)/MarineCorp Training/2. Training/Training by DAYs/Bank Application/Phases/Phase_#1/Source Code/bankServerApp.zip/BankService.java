package com.bankapp.server;

public interface BankService {
	public double showBalance(Account accGotById);
	public double deposit(Account accGotById, double amount);
	public double withdraw(Account accGotById, double amount);
	public double fundTransfer(Account sourceAccount, Account targetAccount, double amount);
	Transaction[] getAllTransactionDetails(Account AccGotById);
}
