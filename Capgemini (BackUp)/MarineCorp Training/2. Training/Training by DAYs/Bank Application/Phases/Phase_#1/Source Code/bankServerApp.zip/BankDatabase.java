package com.bankapp.server;

public class BankDatabase {
		Account account[] = new Account[10];
}
