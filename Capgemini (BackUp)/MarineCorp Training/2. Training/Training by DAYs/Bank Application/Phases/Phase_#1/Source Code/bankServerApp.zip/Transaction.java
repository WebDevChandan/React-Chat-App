package com.bankapp.server;

public class Transaction {
	private int transactionId;
	String transactionType;
	String personName;
	double amountTranfer;
	
	public Transaction() {
		
	}

	public Transaction(int transId, double amountTranf, String transType, String personName){
		this.transactionId=transId;
		this.transactionType=transType;
		this.personName=personName;
		this.amountTranfer=amountTranf;
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", amountTranfer=" + amountTranfer  + ", transactionType=" + transactionType + ", personName="
				+ personName + "]";
	}

	

	

	
	
}
