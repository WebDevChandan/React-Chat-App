package com.cg.BankApplicationService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;

import com.cg.bankapp.bankdao.BankDAOImpl;
import com.cg.bankapp.bankservice.BankServiceImpl;
import com.cg.bankapp.beans.Account;
import com.cg.bankapp.beans.Customer;
import com.cg.bankapp.exceptions.InsufficientBalanceException;
import com.cg.bankapp.util.BankDatabase;

public class BankServiceImplTest {

	// Getting Account DataBase from BankDatabase
	static BankDatabase bDb = new BankDatabase();
	static Account getAccDb[] = bDb.getAccountDb();

	static BankDAOImpl daoImpl = new BankDAOImpl();
	static BankServiceImpl serviceImpl = new BankServiceImpl();
//	static Account gotCorrAccById;
//	static Account gotInCorrAccById;

	@BeforeAll
	void setUpBeforeClass() throws Exception {
		Account account1 = new Account(123450, new Customer(101, "Chandan"), 1000.0);
		Account account2 = new Account(123456, new Customer(201, "Aditya"), 200.0);
//		static Account gotCorrAccById = daoImpl.getAccountById(getAccDb, 123450);
		getAccDb[0] = account1;
		getAccDb[1] = account2;
	}

	@Test
	@DisplayName("Checking Balance of an Account")
	public void checkBalance() {
		assertEquals(serviceImpl.showBalance(getAccDb[0]), 1000, 0.0);

	}

	@Test
	@DisplayName("Depositing Amount to the account")
	public void depositAmount() {
		double amount = 1000;

		// Updated Account Balance After Deposit
		double accountBalance = getAccDb[0].getAccountBalance() + amount;

		assertTrue("If deposited, accBal should Increase", serviceImpl.showBalance(getAccDb[0]) < accountBalance);
		assertEquals(serviceImpl.deposit(getAccDb[0], amount), accountBalance, 0.0);
	}

	@Test
	@DisplayName("Withdrawling Amount from the account")
	public void withdrawAmount() {
		double amount = -1000;

		// Updated Account Balance After Withdrawn
		double accountBalance = getAccDb[0].getAccountBalance() - amount;

		assertTrue("If Withdrawl, accBal should Decrease", serviceImpl.showBalance(getAccDb[0]) > accountBalance);
		try{
			assertEquals(serviceImpl.withdraw(getAccDb[0], amount), accountBalance, 0.0);
		}catch(InsufficientBalanceException e) {
			System.out.println(e);
		}
		
//		assertThrows(InsufficientBalanceException.class, () -> serviceImpl.withdraw(getAccDb[0], amount));
	}

	@Test
	@DisplayName("Tranferring fund from account1 to account2 ")
	public void fundTransfer() {
		double amount = 500;
		
		// Updated Account Balance After Fund withdrawn from 1st Account
		double accountBalance1 = getAccDb[1].getAccountBalance() - amount;
		
		// Updated Account Balance After transfer Fund to 2nd Account
		double accountBalance2 = getAccDb[1].getAccountBalance() + amount;
		
		assertTrue("After withdrawl, 1st account's Bal should Decrease", serviceImpl.showBalance(getAccDb[0]) > accountBalance1);
		assertTrue("If transfer fund, 2nd account's Bal should Increase", serviceImpl.showBalance(getAccDb[1]) < accountBalance2);
		try{
			assertEquals(serviceImpl.fundTransfer(getAccDb[0], getAccDb[1], amount), accountBalance2, 0.0);
		}catch(InsufficientBalanceException e) {
			System.out.println(e);
		}
	}

	@Test
	@DisplayName("Transaction Saved")
	public void transactionDetailsSaved() {
		//If any transaction takes place, this would not null i.e. true
		assertNotNull("If deposit, withdraw or fund Transfer takes place from 1st account (i.e. customer Account)", serviceImpl.getAllTransactionDetails(getAccDb[0])[0]);

		//If no transaction takes place this would be null. Since here transaction is taking place, hence this would not be null anymore.
		assertFalse("If no transaction takes place", serviceImpl.getAllTransactionDetails(getAccDb[0])[0]== null);		
	}
	
	
	@AfterAll
	static void tearDownAfterClass() throws Exception{
		getAccDb[0] = null;
		getAccDb[1] = null;
	}

}
